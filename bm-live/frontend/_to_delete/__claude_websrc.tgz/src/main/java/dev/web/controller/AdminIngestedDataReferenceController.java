package dev.web.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import dev.web.api.bm_a011.IngestedDataReferenceRequest;
import dev.web.api.bm_a011.IngestedDataReferenceResponse;
import dev.web.api.bm_a011.IngestedDataService;
import lombok.RequiredArgsConstructor;

/**
 * 投入済みデータ参照コントローラー
 * @author shiraishitoshio
 *
 */
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class AdminIngestedDataReferenceController {

	private final IngestedDataService service;

	/**
     * 投入済みデータ参照（期間＋テーブル指定）
     *
     * GET /api/admin/ingested
     *   ?from=2026-02-12T00:00:00Z
     *   &to=2026-02-19T23:59:59Z
     *   &tables=FUTURE_MASTER,DATA
     *   &limit=100
     *   &offset=0
     */
    @GetMapping("/admin/ingested")
    public IngestedDataReferenceResponse getIngestedData(
    		@RequestParam(required = false) String country,

            @RequestParam(required = false) Boolean onlyNeedsAttention,

            @RequestParam(defaultValue = "100")
            int limit,

            @RequestParam(defaultValue = "0")
            int offset) {

    	IngestedDataReferenceRequest req = new IngestedDataReferenceRequest();
    	req.setCountry(country);
    	req.setOnlyMissingFinishedOrFuture(Boolean.TRUE.equals(onlyNeedsAttention));
        req.setLimit(limit);
        req.setOffset(offset);

        return service.search(req);
    }

}
