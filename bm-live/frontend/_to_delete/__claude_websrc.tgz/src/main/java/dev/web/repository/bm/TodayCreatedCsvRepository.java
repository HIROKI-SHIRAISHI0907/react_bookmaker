package dev.web.repository.bm;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import dev.web.api.bm_a017.TodayCreatedCsvItemResource;

/**
 * 作成CSV情報取得Repository
 */
@Repository
public class TodayCreatedCsvRepository {

    private final NamedParameterJdbcTemplate bmJdbcTemplate;

    public TodayCreatedCsvRepository(
            @Qualifier("bmJdbcTemplate") NamedParameterJdbcTemplate bmJdbcTemplate
    ) {
        this.bmJdbcTemplate = bmJdbcTemplate;
    }

    /**
     * 指定日作成CSV情報を取得
     * targetDate: yyyy-MM-dd
     */
    public List<TodayCreatedCsvItemResource> findCreatedCsvsByDate(String targetDate, int startOffset, int endOffset) {
    	int limit = endOffset - startOffset;
        if (limit <= 0) {
            throw new IllegalArgumentException("endOffset must be greater than startOffset");
        }

        String sql = """
            SELECT
              cdm.csv_id         AS csvId,
              cdm.data_category  AS dataCategory,
              cdm.season         AS season,
              cdm.home_team_name AS homeTeamName,
              cdm.away_team_name AS awayTeamName,
              cdm.check_fin_flg  AS checkFinFlg,
              TO_CHAR(cdm.register_time, 'YYYY-MM-DD HH24:MI:SS') AS registerTime
            FROM csv_detail_manage cdm
            WHERE cdm.register_time >= CAST(:targetDate AS DATE)
              AND cdm.register_time < CAST(:targetDate AS DATE) + INTERVAL '1 day'
            ORDER BY cdm.register_time DESC, cdm.csv_id ASC
            LIMIT :limit OFFSET :offset
        """;

        return bmJdbcTemplate.query(
            sql,
            new MapSqlParameterSource()
            .addValue("targetDate", targetDate)
            .addValue("limit", limit)
            .addValue("offset", startOffset),
            (rs, n) -> {
                TodayCreatedCsvItemResource item = new TodayCreatedCsvItemResource();
                item.setCsvId(rs.getString("csvId"));
                item.setDataCategory(rs.getString("dataCategory"));
                item.setSeason(rs.getString("season"));
                item.setHomeTeamName(rs.getString("homeTeamName"));
                item.setAwayTeamName(rs.getString("awayTeamName"));
                item.setCheckFinFlg(rs.getString("checkFinFlg"));
                item.setRegisterTime(rs.getString("registerTime"));
                return item;
            }
        );
    }

    /**
     * 全件の総数を取得
     * @param targetDate
     * @return
     */
    public int countCreatedCsvsByDate(String targetDate) {
        String sql = """
            SELECT COUNT(*)
            FROM csv_detail_manage cdm
            WHERE cdm.register_time >= CAST(:targetDate AS DATE)
              AND cdm.register_time < CAST(:targetDate AS DATE) + INTERVAL '1 day'
        """;

        return bmJdbcTemplate.queryForObject(
            sql,
            new MapSqlParameterSource().addValue("targetDate", targetDate),
            Integer.class
        );
    }
}
