package dev.web.repository.bm;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import dev.common.entity.DataEntity;
import dev.common.util.RecordTimeConvertUtil;
import dev.web.api.bm_a025.RealTimeDataDTO;
import lombok.EqualsAndHashCode;

/**
 * DataEntity 用リポジトリ（手動登録/更新向け）
 *
 * - NamedParameterJdbcTemplate で data テーブルを CRUD
 * - キーは seq を想定（必要なら gameId/matchId 等に変更してください）
 */
@Repository
public class BookDataRepository {

	private final NamedParameterJdbcTemplate bmJdbcTemplate;

	public BookDataRepository(
			@Qualifier("bmJdbcTemplate") NamedParameterJdbcTemplate bmJdbcTemplate) {
		this.bmJdbcTemplate = bmJdbcTemplate;
	}

	/** データ形式判定の正規表現を CASE 式として埋め込むための共通 SQL 断片 */
	private static final String CATEGORY_FORMAT_CASE = """
			CASE
			    WHEN data_category ~ '^[^:]+:\\s.+\\s-\\s*ラウンド\\s+\\d+$' THEN 'COUNTRY_LEAGUE_ROUND'
			    WHEN data_category ~ '^[^:]+\\s-\\s*ラウンド\\s+\\d+$'      THEN 'LEAGUE_ROUND'
			    WHEN data_category ~ '^[^:]+:\\s[^:]+$'                    THEN 'COUNTRY_LEAGUE'
			    ELSE NULL
			END
			""";

	/** seq で1件取得 */
	public Optional<DataEntity> findBySeq(String seq) {

		String sql = """
				SELECT
				  seq_key,
				  condition_result_data_seq_id,
				  data_category,
				  times,
				  home_rank,
				  home_team_name,
				  home_score,
				  away_rank,
				  away_team_name,
				  away_score,
				  home_exp,
				  away_exp,
				  home_donation,
				  away_donation,
				  home_shoot_all,
				  away_shoot_all,
				  home_shoot_in,
				  away_shoot_in,
				  home_shoot_out,
				  away_shoot_out,
				  home_block_shoot,
				  away_block_shoot,
				  home_big_chance,
				  away_big_chance,
				  home_corner,
				  away_corner,
				  home_box_shoot_in,
				  away_box_shoot_in,
				  home_box_shoot_out,
				  away_box_shoot_out,
				  home_goal_post,
				  away_goal_post,
				  home_goal_head,
				  away_goal_head,
				  home_keeper_save,
				  away_keeper_save,
				  home_free_kick,
				  away_free_kick,
				  home_offside,
				  away_offside,
				  home_foul,
				  away_foul,
				  home_yellow_card,
				  away_yellow_card,
				  home_red_card,
				  away_red_card,
				  home_slow_in,
				  away_slow_in,
				  home_box_touch,
				  away_box_touch,
				  home_pass_count,
				  away_pass_count,
				  home_long_pass_count,
				  away_long_pass_count,
				  home_final_third_pass_count,
				  away_final_third_pass_count,
				  home_cross_count,
				  away_cross_count,
				  home_tackle_count,
				  away_tackle_count,
				  home_clear_count,
				  away_clear_count,
				  home_duel_count,
				  away_duel_count,
				  home_intercept_count,
				  away_intercept_count,
				  record_time,
				  weather,
				  temparature,
				  humid,
				  judge_member,
				  home_manager,
				  away_manager,
				  home_formation,
				  away_formation,
				  studium,
				  capacity,
				  audience,
				  home_max_getting_scorer,
				  away_max_getting_scorer,
				  home_max_getting_scorer_game_situation,
				  away_max_getting_scorer_game_situation,
				  home_team_home_score,
				  home_team_home_lost,
				  away_team_home_score,
				  away_team_home_lost,
				  home_team_away_score,
				  home_team_away_lost,
				  away_team_away_score,
				  away_team_away_lost,
				  notice_flg,
				  goal_time,
				  goal_team_member,
				  judge,
				  home_team_style,
				  away_team_style,
				  probablity,
				  prediction_score_time
				FROM static_data
				WHERE seq_key = :seqKey
				""";

		List<DataEntity> list = bmJdbcTemplate.query(
				sql,
				Map.of("seqKey", seq),
				(rs, rowNum) -> mapDataEntity(rs));

		return list.stream().findFirst();
	}

	/** seq 複数で取得 */
	public List<DataEntity> findBySeqList(List<Integer> seqList) {
		if (seqList == null || seqList.isEmpty())
			return List.of();

		String sql = """
				SELECT DISTINCT
				  seq_key,
				  condition_result_data_seq_id,
				  data_category,
				  times,
				  home_rank,
				  home_team_name,
				  home_score,
				  away_rank,
				  away_team_name,
				  away_score,
				  home_exp,
				  away_exp,
				  home_donation,
				  away_donation,
				  home_shoot_all,
				  away_shoot_all,
				  home_shoot_in,
				  away_shoot_in,
				  home_shoot_out,
				  away_shoot_out,
				  home_block_shoot,
				  away_block_shoot,
				  home_big_chance,
				  away_big_chance,
				  home_corner,
				  away_corner,
				  home_box_shoot_in,
				  away_box_shoot_in,
				  home_box_shoot_out,
				  away_box_shoot_out,
				  home_goal_post,
				  away_goal_post,
				  home_goal_head,
				  away_goal_head,
				  home_keeper_save,
				  away_keeper_save,
				  home_free_kick,
				  away_free_kick,
				  home_offside,
				  away_offside,
				  home_foul,
				  away_foul,
				  home_yellow_card,
				  away_yellow_card,
				  home_red_card,
				  away_red_card,
				  home_slow_in,
				  away_slow_in,
				  home_box_touch,
				  away_box_touch,
				  home_pass_count,
				  away_pass_count,
				  home_long_pass_count,
				  away_long_pass_count,
				  home_final_third_pass_count,
				  away_final_third_pass_count,
				  home_cross_count,
				  away_cross_count,
				  home_tackle_count,
				  away_tackle_count,
				  home_clear_count,
				  away_clear_count,
				  home_duel_count,
				  away_duel_count,
				  home_intercept_count,
				  away_intercept_count,
				  record_time,
				  weather,
				  temparature,
				  humid,
				  judge_member,
				  home_manager,
				  away_manager,
				  home_formation,
				  away_formation,
				  studium,
				  capacity,
				  audience,
				  home_max_getting_scorer,
				  away_max_getting_scorer,
				  home_max_getting_scorer_game_situation,
				  away_max_getting_scorer_game_situation,
				  home_team_home_score,
				  home_team_home_lost,
				  away_team_home_score,
				  away_team_home_lost,
				  home_team_away_score,
				  home_team_away_lost,
				  away_team_away_score,
				  away_team_away_lost,
				  notice_flg,
				  goal_time,
				  goal_team_member,
				  judge,
				  home_team_style,
				  away_team_style,
				  probablity,
				  prediction_score_time
				FROM static_data
				WHERE seq_key IN (:seqList)
				""";

		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("seqList", seqList);

		return bmJdbcTemplate.query(sql, params, (rs, rowNum) -> mapDataEntity(rs));
	}

	/** 新規登録（手動登録） */
	public int insert(DataEntity e) {

		String sql = """
				INSERT INTO static_data (
				  seq_key,
				  condition_result_data_seq_id,
				  data_category,
				  times,
				  home_rank,
				  home_team_name,
				  home_score,
				  away_rank,
				  away_team_name,
				  away_score,
				  home_exp,
				  away_exp,
				  home_donation,
				  away_donation,
				  home_shoot_all,
				  away_shoot_all,
				  home_shoot_in,
				  away_shoot_in,
				  home_shoot_out,
				  away_shoot_out,
				  home_block_shoot,
				  away_block_shoot,
				  home_big_chance,
				  away_big_chance,
				  home_corner,
				  away_corner,
				  home_box_shoot_in,
				  away_box_shoot_in,
				  home_box_shoot_out,
				  away_box_shoot_out,
				  home_goal_post,
				  away_goal_post,
				  home_goal_head,
				  away_goal_head,
				  home_keeper_save,
				  away_keeper_save,
				  home_free_kick,
				  away_free_kick,
				  home_offside,
				  away_offside,
				  home_foul,
				  away_foul,
				  home_yellow_card,
				  away_yellow_card,
				  home_red_card,
				  away_red_card,
				  home_slow_in,
				  away_slow_in,
				  home_box_touch,
				  away_box_touch,
				  home_pass_count,
				  away_pass_count,
				  home_long_pass_count,
				  away_long_pass_count,
				  home_final_third_pass_count,
				  away_final_third_pass_count,
				  home_cross_count,
				  away_cross_count,
				  home_tackle_count,
				  away_tackle_count,
				  home_clear_count,
				  away_clear_count,
				  home_duel_count,
				  away_duel_count,
				  home_intercept_count,
				  away_intercept_count,
				  record_time,
				  weather,
				  temparature,
				  humid,
				  judge_member,
				  home_manager,
				  away_manager,
				  home_formation,
				  away_formation,
				  studium,
				  capacity,
				  audience,
				  home_max_getting_scorer,
				  away_max_getting_scorer,
				  home_max_getting_scorer_game_situation,
				  away_max_getting_scorer_game_situation,
				  home_team_home_score,
				  home_team_home_lost,
				  away_team_home_score,
				  away_team_home_lost,
				  home_team_away_score,
				  home_team_away_lost,
				  away_team_away_score,
				  away_team_away_lost,
				  notice_flg,
				  goal_time,
				  goal_team_member,
				  judge,
				  home_team_style,
				  away_team_style,
				  probablity,
				  prediction_score_time
				) VALUES (
				  :seqKey,
				  :conditionResultDataSeqId,
				  :dataCategory,
				  :times,
				  :homeRank,
				  :homeTeamName,
				  :homeScore,
				  :awayRank,
				  :awayTeamName,
				  :awayScore,
				  :homeExp,
				  :awayExp,
				  :homeDonation,
				  :awayDonation,
				  :homeShootAll,
				  :awayShootAll,
				  :homeShootIn,
				  :awayShootIn,
				  :homeShootOut,
				  :awayShootOut,
				  :homeBlockShoot,
				  :awayBlockShoot,
				  :homeBigChance,
				  :awayBigChance,
				  :homeCorner,
				  :awayCorner,
				  :homeBoxShootIn,
				  :awayBoxShootIn,
				  :homeBoxShootOut,
				  :awayBoxShootOut,
				  :homeGoalPost,
				  :awayGoalPost,
				  :homeGoalHead,
				  :awayGoalHead,
				  :homeKeeperSave,
				  :awayKeeperSave,
				  :homeFreeKick,
				  :awayFreeKick,
				  :homeOffside,
				  :awayOffside,
				  :homeFoul,
				  :awayFoul,
				  :homeYellowCard,
				  :awayYellowCard,
				  :homeRedCard,
				  :awayRedCard,
				  :homeSlowIn,
				  :awaySlowIn,
				  :homeBoxTouch,
				  :awayBoxTouch,
				  :homePassCount,
				  :awayPassCount,
				  :homeLongPassCount,
				  :awayLongPassCount,
				  :homeFinalThirdPassCount,
				  :awayFinalThirdPassCount,
				  :homeCrossCount,
				  :awayCrossCount,
				  :homeTackleCount,
				  :awayTackleCount,
				  :homeClearCount,
				  :awayClearCount,
				  :homeDuelCount,
				  :awayDuelCount,
				  :homeInterceptCount,
				  :awayInterceptCount,
				  :recordTime,
				  :weather,
				  :temparature,
				  :humid,
				  :judgeMember,
				  :homeManager,
				  :awayManager,
				  :homeFormation,
				  :awayFormation,
				  :studium,
				  :capacity,
				  :audience,
				  :homeMaxGettingScorer,
				  :awayMaxGettingScorer,
				  :homeMaxGettingScorerGameSituation,
				  :awayMaxGettingScorerGameSituation,
				  :homeTeamHomeScore,
				  :homeTeamHomeLost,
				  :awayTeamHomeScore,
				  :awayTeamHomeLost,
				  :homeTeamAwayScore,
				  :homeTeamAwayLost,
				  :awayTeamAwayScore,
				  :awayTeamAwayLost,
				  :noticeFlg,
				  :goalTime,
				  :goalTeamMember,
				  :judge,
				  :homeTeamStyle,
				  :awayTeamStyle,
				  :probablity,
				  :predictionScoreTime
				)
				""";

		return bmJdbcTemplate.update(sql, toParams(e));
	}

	/** 更新（seq 指定） */
	public int updateBySeq(DataEntity e) {

		String sql = """
				UPDATE static_data SET
				  condition_result_data_seq_id = :conditionResultDataSeqId,
				  data_category               = :dataCategory,
				  times                       = :times,
				  home_rank                   = :homeRank,
				  home_team_name              = :homeTeamName,
				  home_score                  = :homeScore,
				  away_rank                   = :awayRank,
				  away_team_name              = :awayTeamName,
				  away_score                  = :awayScore,
				  home_exp                    = :homeExp,
				  away_exp                    = :awayExp,
				  home_donation               = :homeDonation,
				  away_donation               = :awayDonation,
				  home_shoot_all              = :homeShootAll,
				  away_shoot_all              = :awayShootAll,
				  home_shoot_in               = :homeShootIn,
				  away_shoot_in               = :awayShootIn,
				  home_shoot_out              = :homeShootOut,
				  away_shoot_out              = :awayShootOut,
				  home_block_shoot            = :homeBlockShoot,
				  away_block_shoot            = :awayBlockShoot,
				  home_big_chance             = :homeBigChance,
				  away_big_chance             = :awayBigChance,
				  home_corner                 = :homeCorner,
				  away_corner                 = :awayCorner,
				  home_box_shoot_in           = :homeBoxShootIn,
				  away_box_shoot_in           = :awayBoxShootIn,
				  home_box_shoot_out          = :homeBoxShootOut,
				  away_box_shoot_out          = :awayBoxShootOut,
				  home_goal_post              = :homeGoalPost,
				  away_goal_post              = :awayGoalPost,
				  home_goal_head              = :homeGoalHead,
				  away_goal_head              = :awayGoalHead,
				  home_keeper_save            = :homeKeeperSave,
				  away_keeper_save            = :awayKeeperSave,
				  home_free_kick              = :homeFreeKick,
				  away_free_kick              = :awayFreeKick,
				  home_offside                = :homeOffside,
				  away_offside                = :awayOffside,
				  home_foul                   = :homeFoul,
				  away_foul                   = :awayFoul,
				  home_yellow_card            = :homeYellowCard,
				  away_yellow_card            = :awayYellowCard,
				  home_red_card               = :homeRedCard,
				  away_red_card               = :awayRedCard,
				  home_slow_in                = :homeSlowIn,
				  away_slow_in                = :awaySlowIn,
				  home_box_touch              = :homeBoxTouch,
				  away_box_touch              = :awayBoxTouch,
				  home_pass_count             = :homePassCount,
				  away_pass_count             = :awayPassCount,
				  home_long_pass_count        = :homeLongPassCount,
				  away_long_pass_count        = :awayLongPassCount,
				  home_final_third_pass_count = :homeFinalThirdPassCount,
				  away_final_third_pass_count = :awayFinalThirdPassCount,
				  home_cross_count            = :homeCrossCount,
				  away_cross_count            = :awayCrossCount,
				  home_tackle_count           = :homeTackleCount,
				  away_tackle_count           = :awayTackleCount,
				  home_clear_count            = :homeClearCount,
				  away_clear_count            = :awayClearCount,
				  home_duel_count             = :homeDuelCount,
				  away_duel_count             = :awayDuelCount,
				  home_intercept_count        = :homeInterceptCount,
				  away_intercept_count        = :awayInterceptCount,
				  record_time                 = :recordTime,
				  weather                     = :weather,
				  temparature                 = :temparature,
				  humid                       = :humid,
				  judge_member                = :judgeMember,
				  home_manager                = :homeManager,
				  away_manager                = :awayManager,
				  home_formation              = :homeFormation,
				  away_formation              = :awayFormation,
				  studium                     = :studium,
				  capacity                    = :capacity,
				  audience                    = :audience,
				  home_max_getting_scorer     = :homeMaxGettingScorer,
				  away_max_getting_scorer     = :awayMaxGettingScorer,
				  home_max_getting_scorer_game_situation = :homeMaxGettingScorerGameSituation,
				  away_max_getting_scorer_game_situation = :awayMaxGettingScorerGameSituation,
				  home_team_home_score        = :homeTeamHomeScore,
				  home_team_home_lost         = :homeTeamHomeLost,
				  away_team_home_score        = :awayTeamHomeScore,
				  away_team_home_lost         = :awayTeamHomeLost,
				  home_team_away_score        = :homeTeamAwayScore,
				  home_team_away_lost         = :homeTeamAwayLost,
				  away_team_away_score        = :awayTeamAwayScore,
				  away_team_away_lost         = :awayTeamAwayLost,
				  notice_flg                  = :noticeFlg,
				  goal_time                   = :goalTime,
				  goal_team_member            = :goalTeamMember,
				  judge                       = :judge,
				  home_team_style             = :homeTeamStyle,
				  away_team_style             = :awayTeamStyle,
				  probablity                  = :probablity,
				  prediction_score_time       = :predictionScoreTime
				WHERE seq_key = :seqKey
				""";

		return bmJdbcTemplate.update(sql, toParams(e));
	}

	/** 物理削除（必要なら） */
	public int deleteBySeq(String seq) {
		String sql = "DELETE FROM static_data WHERE seq_key = :seqKey";
		return bmJdbcTemplate.update(sql, Map.of("seqKey", seq));
	}

	/** ====== row mapper ====== */
	private static DataEntity mapDataEntity(java.sql.ResultSet rs) throws java.sql.SQLException {
		DataEntity e = new DataEntity();

		e.setSeqKey(rs.getString("seq_key"));
		e.setConditionResultDataSeqId(rs.getString("condition_result_data_seq_id"));
		e.setDataCategory(rs.getString("data_category"));
		e.setTimes(rs.getString("times"));
		e.setHomeRank(rs.getString("home_rank"));
		e.setHomeTeamName(rs.getString("home_team_name"));
		e.setHomeScore(rs.getString("home_score"));
		e.setAwayRank(rs.getString("away_rank"));
		e.setAwayTeamName(rs.getString("away_team_name"));
		e.setAwayScore(rs.getString("away_score"));
		e.setHomeExp(rs.getString("home_exp"));
		e.setAwayExp(rs.getString("away_exp"));
		e.setHomeDonation(rs.getString("home_donation"));
		e.setAwayDonation(rs.getString("away_donation"));
		e.setHomeShootAll(rs.getString("home_shoot_all"));
		e.setAwayShootAll(rs.getString("away_shoot_all"));
		e.setHomeShootIn(rs.getString("home_shoot_in"));
		e.setAwayShootIn(rs.getString("away_shoot_in"));
		e.setHomeShootOut(rs.getString("home_shoot_out"));
		e.setAwayShootOut(rs.getString("away_shoot_out"));
		e.setHomeBlockShoot(rs.getString("home_block_shoot"));
		e.setAwayBlockShoot(rs.getString("away_block_shoot"));
		e.setHomeBigChance(rs.getString("home_big_chance"));
		e.setAwayBigChance(rs.getString("away_big_chance"));
		e.setHomeCorner(rs.getString("home_corner"));
		e.setAwayCorner(rs.getString("away_corner"));
		e.setHomeBoxShootIn(rs.getString("home_box_shoot_in"));
		e.setAwayBoxShootIn(rs.getString("away_box_shoot_in"));
		e.setHomeBoxShootOut(rs.getString("home_box_shoot_out"));
		e.setAwayBoxShootOut(rs.getString("away_box_shoot_out"));
		e.setHomeGoalPost(rs.getString("home_goal_post"));
		e.setAwayGoalPost(rs.getString("away_goal_post"));
		e.setHomeGoalHead(rs.getString("home_goal_head"));
		e.setAwayGoalHead(rs.getString("away_goal_head"));
		e.setHomeKeeperSave(rs.getString("home_keeper_save"));
		e.setAwayKeeperSave(rs.getString("away_keeper_save"));
		e.setHomeFreeKick(rs.getString("home_free_kick"));
		e.setAwayFreeKick(rs.getString("away_free_kick"));
		e.setHomeOffside(rs.getString("home_offside"));
		e.setAwayOffside(rs.getString("away_offside"));
		e.setHomeFoul(rs.getString("home_foul"));
		e.setAwayFoul(rs.getString("away_foul"));
		e.setHomeYellowCard(rs.getString("home_yellow_card"));
		e.setAwayYellowCard(rs.getString("away_yellow_card"));
		e.setHomeRedCard(rs.getString("home_red_card"));
		e.setAwayRedCard(rs.getString("away_red_card"));
		e.setHomeSlowIn(rs.getString("home_slow_in"));
		e.setAwaySlowIn(rs.getString("away_slow_in"));
		e.setHomeBoxTouch(rs.getString("home_box_touch"));
		e.setAwayBoxTouch(rs.getString("away_box_touch"));
		e.setHomePassCount(rs.getString("home_pass_count"));
		e.setAwayPassCount(rs.getString("away_pass_count"));
		e.setHomeLongPassCount(rs.getString("home_long_pass_count"));
		e.setAwayLongPassCount(rs.getString("away_long_pass_count"));
		e.setHomeFinalThirdPassCount(rs.getString("home_final_third_pass_count"));
		e.setAwayFinalThirdPassCount(rs.getString("away_final_third_pass_count"));
		e.setHomeCrossCount(rs.getString("home_cross_count"));
		e.setAwayCrossCount(rs.getString("away_cross_count"));
		e.setHomeTackleCount(rs.getString("home_tackle_count"));
		e.setAwayTackleCount(rs.getString("away_tackle_count"));
		e.setHomeClearCount(rs.getString("home_clear_count"));
		e.setAwayClearCount(rs.getString("away_clear_count"));
		e.setHomeDuelCount(rs.getString("home_duel_count"));
		e.setAwayDuelCount(rs.getString("away_duel_count"));
		e.setHomeInterceptCount(rs.getString("home_intercept_count"));
		e.setAwayInterceptCount(rs.getString("away_intercept_count"));

		e.setRecordTime(rs.getString("record_time"));
		e.setWeather(rs.getString("weather"));
		e.setTemparature(rs.getString("temparature"));
		e.setHumid(rs.getString("humid"));
		e.setJudgeMember(rs.getString("judge_member"));
		e.setHomeManager(rs.getString("home_manager"));
		e.setAwayManager(rs.getString("away_manager"));
		e.setHomeFormation(rs.getString("home_formation"));
		e.setAwayFormation(rs.getString("away_formation"));
		e.setStudium(rs.getString("studium"));
		e.setCapacity(rs.getString("capacity"));
		e.setAudience(rs.getString("audience"));
		e.setHomeMaxGettingScorer(rs.getString("home_max_getting_scorer"));
		e.setAwayMaxGettingScorer(rs.getString("away_max_getting_scorer"));
		e.setHomeMaxGettingScorerGameSituation(rs.getString("home_max_getting_scorer_game_situation"));
		e.setAwayMaxGettingScorerGameSituation(rs.getString("away_max_getting_scorer_game_situation"));
		e.setHomeTeamHomeScore(rs.getString("home_team_home_score"));
		e.setHomeTeamHomeLost(rs.getString("home_team_home_lost"));
		e.setAwayTeamHomeScore(rs.getString("away_team_home_score"));
		e.setAwayTeamHomeLost(rs.getString("away_team_home_lost"));
		e.setHomeTeamAwayScore(rs.getString("home_team_away_score"));
		e.setHomeTeamAwayLost(rs.getString("home_team_away_lost"));
		e.setAwayTeamAwayScore(rs.getString("away_team_away_score"));
		e.setAwayTeamAwayLost(rs.getString("away_team_away_lost"));
		e.setNoticeFlg(rs.getString("notice_flg"));
		e.setGoalTime(rs.getString("goal_time"));
		e.setGoalTeamMember(rs.getString("goal_team_member"));
		e.setJudge(rs.getString("judge"));
		e.setHomeTeamStyle(rs.getString("home_team_style"));
		e.setAwayTeamStyle(rs.getString("away_team_style"));
		e.setProbablity(rs.getString("probablity"));
		e.setPredictionScoreTime(rs.getString("prediction_score_time"));

		return e;
	}

	/** ====== params builder ====== */
	private static MapSqlParameterSource toParams(DataEntity e) {
		MapSqlParameterSource p = new MapSqlParameterSource();

		p.addValue("seqKey", e.getSeqKey());
		p.addValue("conditionResultDataSeqId", e.getConditionResultDataSeqId());
		p.addValue("dataCategory", e.getDataCategory());
		p.addValue("times", e.getTimes());
		p.addValue("homeRank", e.getHomeRank());
		p.addValue("homeTeamName", e.getHomeTeamName());
		p.addValue("homeScore", e.getHomeScore());
		p.addValue("awayRank", e.getAwayRank());
		p.addValue("awayTeamName", e.getAwayTeamName());
		p.addValue("awayScore", e.getAwayScore());
		p.addValue("homeExp", e.getHomeExp());
		p.addValue("awayExp", e.getAwayExp());
		p.addValue("homeDonation", e.getHomeDonation());
		p.addValue("awayDonation", e.getAwayDonation());
		p.addValue("homeShootAll", e.getHomeShootAll());
		p.addValue("awayShootAll", e.getAwayShootAll());
		p.addValue("homeShootIn", e.getHomeShootIn());
		p.addValue("awayShootIn", e.getAwayShootIn());
		p.addValue("homeShootOut", e.getHomeShootOut());
		p.addValue("awayShootOut", e.getAwayShootOut());
		p.addValue("homeBlockShoot", e.getHomeBlockShoot());
		p.addValue("awayBlockShoot", e.getAwayBlockShoot());
		p.addValue("homeBigChance", e.getHomeBigChance());
		p.addValue("awayBigChance", e.getAwayBigChance());
		p.addValue("homeCorner", e.getHomeCorner());
		p.addValue("awayCorner", e.getAwayCorner());
		p.addValue("homeBoxShootIn", e.getHomeBoxShootIn());
		p.addValue("awayBoxShootIn", e.getAwayBoxShootIn());
		p.addValue("homeBoxShootOut", e.getHomeBoxShootOut());
		p.addValue("awayBoxShootOut", e.getAwayBoxShootOut());
		p.addValue("homeGoalPost", e.getHomeGoalPost());
		p.addValue("awayGoalPost", e.getAwayGoalPost());
		p.addValue("homeGoalHead", e.getHomeGoalHead());
		p.addValue("awayGoalHead", e.getAwayGoalHead());
		p.addValue("homeKeeperSave", e.getHomeKeeperSave());
		p.addValue("awayKeeperSave", e.getAwayKeeperSave());
		p.addValue("homeFreeKick", e.getHomeFreeKick());
		p.addValue("awayFreeKick", e.getAwayFreeKick());
		p.addValue("homeOffside", e.getHomeOffside());
		p.addValue("awayOffside", e.getAwayOffside());
		p.addValue("homeFoul", e.getHomeFoul());
		p.addValue("awayFoul", e.getAwayFoul());
		p.addValue("homeYellowCard", e.getHomeYellowCard());
		p.addValue("awayYellowCard", e.getAwayYellowCard());
		p.addValue("homeRedCard", e.getHomeRedCard());
		p.addValue("awayRedCard", e.getAwayRedCard());
		p.addValue("homeSlowIn", e.getHomeSlowIn());
		p.addValue("awaySlowIn", e.getAwaySlowIn());
		p.addValue("homeBoxTouch", e.getHomeBoxTouch());
		p.addValue("awayBoxTouch", e.getAwayBoxTouch());
		p.addValue("homePassCount", e.getHomePassCount());
		p.addValue("awayPassCount", e.getAwayPassCount());
		p.addValue("homeLongPassCount", e.getHomeLongPassCount());
		p.addValue("awayLongPassCount", e.getAwayLongPassCount());
		p.addValue("homeFinalThirdPassCount", e.getHomeFinalThirdPassCount());
		p.addValue("awayFinalThirdPassCount", e.getAwayFinalThirdPassCount());
		p.addValue("homeCrossCount", e.getHomeCrossCount());
		p.addValue("awayCrossCount", e.getAwayCrossCount());
		p.addValue("homeTackleCount", e.getHomeTackleCount());
		p.addValue("awayTackleCount", e.getAwayTackleCount());
		p.addValue("homeClearCount", e.getHomeClearCount());
		p.addValue("awayClearCount", e.getAwayClearCount());
		p.addValue("homeDuelCount", e.getHomeDuelCount());
		p.addValue("awayDuelCount", e.getAwayDuelCount());
		p.addValue("homeInterceptCount", e.getHomeInterceptCount());
		p.addValue("awayInterceptCount", e.getAwayInterceptCount());
		p.addValue("recordTime", e.getRecordTime());
		p.addValue("weather", e.getWeather());
		p.addValue("temparature", e.getTemparature());
		p.addValue("humid", e.getHumid());
		p.addValue("judgeMember", e.getJudgeMember());
		p.addValue("homeManager", e.getHomeManager());
		p.addValue("awayManager", e.getAwayManager());
		p.addValue("homeFormation", e.getHomeFormation());
		p.addValue("awayFormation", e.getAwayFormation());
		p.addValue("studium", e.getStudium());
		p.addValue("capacity", e.getCapacity());
		p.addValue("audience", e.getAudience());
		p.addValue("homeMaxGettingScorer", e.getHomeMaxGettingScorer());
		p.addValue("awayMaxGettingScorer", e.getAwayMaxGettingScorer());
		p.addValue("homeMaxGettingScorerGameSituation", e.getHomeMaxGettingScorerGameSituation());
		p.addValue("awayMaxGettingScorerGameSituation", e.getAwayMaxGettingScorerGameSituation());
		p.addValue("homeTeamHomeScore", e.getHomeTeamHomeScore());
		p.addValue("homeTeamHomeLost", e.getHomeTeamHomeLost());
		p.addValue("awayTeamHomeScore", e.getAwayTeamHomeScore());
		p.addValue("awayTeamHomeLost", e.getAwayTeamHomeLost());
		p.addValue("homeTeamAwayScore", e.getHomeTeamAwayScore());
		p.addValue("homeTeamAwayLost", e.getHomeTeamAwayLost());
		p.addValue("awayTeamAwayScore", e.getAwayTeamAwayScore());
		p.addValue("awayTeamAwayLost", e.getAwayTeamAwayLost());
		p.addValue("noticeFlg", e.getNoticeFlg());
		p.addValue("goalTime", e.getGoalTime());
		p.addValue("goalTeamMember", e.getGoalTeamMember());
		p.addValue("judge", e.getJudge());
		p.addValue("homeTeamStyle", e.getHomeTeamStyle());
		p.addValue("awayTeamStyle", e.getAwayTeamStyle());
		p.addValue("probablity", e.getProbablity());
		p.addValue("predictionScoreTime", e.getPredictionScoreTime());

		return p;
	}

	// ========= data =========
	public List<DataIngestRow> findDataByRegisterTime(String country) {

		StringBuilder sql = new StringBuilder("""
				SELECT
				    seq_key,
				    data_category,
				    times,
				    record_time,
				    match_id,
				    game_id,
				    game_link,
				    home_team_name,
				    away_team_name
				FROM static_data
				WHERE 1 = 1
				""");

		MapSqlParameterSource params = new MapSqlParameterSource();

		if (country != null && !country.isBlank()) {
			sql.append("""
					AND data_category LIKE :countryLike
					""");
			params.addValue("countryLike", country.trim() + ":%");
		}

		sql.append("""
				ORDER BY COALESCE(record_time) DESC, seq_key DESC
				""");

		return bmJdbcTemplate.query(sql.toString(), params, (rs, rowNum) -> {
			DataIngestRow r = new DataIngestRow();
			r.seq = rs.getString("seq_key");
			r.dataCategory = rs.getString("data_category");
			r.times = rs.getString("times");

			r.recordTime = rs.getTimestamp("record_time");

			r.matchId = rs.getString("match_id");
			r.gameId = rs.getString("game_id");
			r.gameLink = rs.getString("game_link");
			r.homeTeamName = rs.getString("home_team_name");
			r.awayTeamName = rs.getString("away_team_name");
			return r;
		});
	}

	public static class DataIngestRow {
		public String seq;
		public String dataCategory;
		public String times;
		public String homeTeamName;
		public String awayTeamName;
		public Timestamp recordTime;
		public String gameId;
		public String gameLink;
		public String matchId;
	}

	/** dataを全件 DataEntity で取得（重いので注意） */
	public List<DataEntity> findAll() {
		String sql = """
				SELECT
				  seq_key,
				  condition_result_data_seq_id,
				  data_category,
				  times,
				  home_rank,
				  home_team_name,
				  home_score,
				  away_rank,
				  away_team_name,
				  away_score,
				  home_exp,
				  away_exp,
				  home_donation,
				  away_donation,
				  home_shoot_all,
				  away_shoot_all,
				  home_shoot_in,
				  away_shoot_in,
				  home_shoot_out,
				  away_shoot_out,
				  home_block_shoot,
				  away_block_shoot,
				  home_big_chance,
				  away_big_chance,
				  home_corner,
				  away_corner,
				  home_box_shoot_in,
				  away_box_shoot_in,
				  home_box_shoot_out,
				  away_box_shoot_out,
				  home_goal_post,
				  away_goal_post,
				  home_goal_head,
				  away_goal_head,
				  home_keeper_save,
				  away_keeper_save,
				  home_free_kick,
				  away_free_kick,
				  home_offside,
				  away_offside,
				  home_foul,
				  away_foul,
				  home_yellow_card,
				  away_yellow_card,
				  home_red_card,
				  away_red_card,
				  home_slow_in,
				  away_slow_in,
				  home_box_touch,
				  away_box_touch,
				  home_pass_count,
				  away_pass_count,
				  home_long_pass_count,
				  away_long_pass_count,
				  home_final_third_pass_count,
				  away_final_third_pass_count,
				  home_cross_count,
				  away_cross_count,
				  home_tackle_count,
				  away_tackle_count,
				  home_clear_count,
				  away_clear_count,
				  home_duel_count,
				  away_duel_count,
				  home_intercept_count,
				  away_intercept_count,
				  record_time,
				  weather,
				  temparature,
				  humid,
				  judge_member,
				  home_manager,
				  away_manager,
				  home_formation,
				  away_formation,
				  studium,
				  capacity,
				  audience,
				  home_max_getting_scorer,
				  away_max_getting_scorer,
				  home_max_getting_scorer_game_situation,
				  away_max_getting_scorer_game_situation,
				  home_team_home_score,
				  home_team_home_lost,
				  away_team_home_score,
				  away_team_home_lost,
				  home_team_away_score,
				  home_team_away_lost,
				  away_team_away_score,
				  away_team_away_lost,
				  notice_flg,
				  goal_time,
				  goal_team_member,
				  judge,
				  home_team_style,
				  away_team_style,
				  probablity,
				  prediction_score_time
				FROM static_data
				ORDER BY seq_key DESC
				""";

		return bmJdbcTemplate.query(sql, new MapSqlParameterSource(), (rs, rowNum) -> mapDataEntity(rs));
	}

	public Optional<DataEntity> findByBusinessKey(
			String condId, String category, String times, String home, String away) {
		String sql = """
				SELECT
				  seq_key,
				  condition_result_data_seq_id,
				  data_category,
				  times,
				  home_rank,
				  home_team_name,
				  home_score,
				  away_rank,
				  away_team_name,
				  away_score,
				  home_exp,
				  away_exp,
				  home_donation,
				  away_donation,
				  home_shoot_all,
				  away_shoot_all,
				  home_shoot_in,
				  away_shoot_in,
				  home_shoot_out,
				  away_shoot_out,
				  home_block_shoot,
				  away_block_shoot,
				  home_big_chance,
				  away_big_chance,
				  home_corner,
				  away_corner,
				  home_box_shoot_in,
				  away_box_shoot_in,
				  home_box_shoot_out,
				  away_box_shoot_out,
				  home_goal_post,
				  away_goal_post,
				  home_goal_head,
				  away_goal_head,
				  home_keeper_save,
				  away_keeper_save,
				  home_free_kick,
				  away_free_kick,
				  home_offside,
				  away_offside,
				  home_foul,
				  away_foul,
				  home_yellow_card,
				  away_yellow_card,
				  home_red_card,
				  away_red_card,
				  home_slow_in,
				  away_slow_in,
				  home_box_touch,
				  away_box_touch,
				  home_pass_count,
				  away_pass_count,
				  home_long_pass_count,
				  away_long_pass_count,
				  home_final_third_pass_count,
				  away_final_third_pass_count,
				  home_cross_count,
				  away_cross_count,
				  home_tackle_count,
				  away_tackle_count,
				  home_clear_count,
				  away_clear_count,
				  home_duel_count,
				  away_duel_count,
				  home_intercept_count,
				  away_intercept_count,
				  record_time,
				  weather,
				  temparature,
				  humid,
				  judge_member,
				  home_manager,
				  away_manager,
				  home_formation,
				  away_formation,
				  studium,
				  capacity,
				  audience,
				  home_max_getting_scorer,
				  away_max_getting_scorer,
				  home_max_getting_scorer_game_situation,
				  away_max_getting_scorer_game_situation,
				  home_team_home_score,
				  home_team_home_lost,
				  away_team_home_score,
				  away_team_home_lost,
				  home_team_away_score,
				  home_team_away_lost,
				  away_team_away_score,
				  away_team_away_lost,
				  notice_flg,
				  goal_time,
				  goal_team_member,
				  judge,
				  home_team_style,
				  away_team_style,
				  probablity,
				  prediction_score_time
				FROM static_data
				WHERE condition_result_data_seq_id = :condId
				  AND data_category = :category
				  AND times = :times
				  AND normalize(home_team_name, NFKC) = normalize(:home, NFKC)
				  AND normalize(away_team_name, NFKC) = normalize(:away, NFKC)
				""";

		var params = new MapSqlParameterSource()
				.addValue("condId", condId)
				.addValue("category", category)
				.addValue("times", times)
				.addValue("home", home)
				.addValue("away", away);

		List<DataEntity> list = bmJdbcTemplate.query(sql, params, (rs, rowNum) -> mapDataEntity(rs));
		return list.stream().findFirst();
	}

	public List<BusinessGroupCountRow> countByBusinessGroupExcludeNullOrBlank() {

		String sql = """
				SELECT
				  condition_result_data_seq_id,
				  ANY_VALUE(data_category) AS data_category,
				  home_team_name,
				  away_team_name,
				  COUNT(*) AS cnt
				FROM static_data
				WHERE condition_result_data_seq_id IS NOT NULL AND TRIM(condition_result_data_seq_id) <> ''
					AND data_category IS NOT NULL               AND TRIM(data_category) <> ''
					AND normalize(home_team_name, NFKC) IS NOT NULL  AND TRIM(home_team_name) <> ''
					AND normalize(away_team_name, NFKC) IS NOT NULL  AND TRIM(away_team_name) <> ''
				GROUP BY
					condition_result_data_seq_id,
					home_team_name,
					away_team_name
					ORDER BY cnt DESC
				""";

		return bmJdbcTemplate.query(sql, new MapSqlParameterSource(), (rs, rowNum) -> {
			BusinessGroupCountRow r = new BusinessGroupCountRow();
			r.conditionResultDataSeqId = rs.getString("condition_result_data_seq_id");
			r.dataCategory = rs.getString("data_category");
			r.homeTeamName = rs.getString("home_team_name");
			r.awayTeamName = rs.getString("away_team_name");
			r.cnt = rs.getLong("cnt");
			return r;
		});
	}

	/**
	 * LIVEデータ存在チェック（鮮度は問わない）
	 * @author shiraishitoshio
	 */
	public int countByLiveData(String homeTeamName, String awayTeamName) {

		StringBuilder sql = new StringBuilder("""
				        SELECT COUNT(*) AS cnt
				FROM static_data
				WHERE normalize(home_team_name, NFKC) = normalize(:homeTeamName, NFKC)
				AND normalize(away_team_name, NFKC) = normalize(:awayTeamName, NFKC)
				AND times IS NOT NULL
				AND TRIM(times) <> ''
				AND REPLACE(TRIM(normalize(times, NFKC)), ' ', '') <> '終了済'
				AND REPLACE(TRIM(normalize(times, NFKC)), ' ', '') NOT LIKE '%ペナルティ%'
				        """);

		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("homeTeamName", homeTeamName);
		params.addValue("awayTeamName", awayTeamName);

		Integer count = bmJdbcTemplate.queryForObject(
				sql.toString(),
				params,
				Integer.class);

		return count != null ? count : 0;
	}

	/**
	 * 終了済みデータ存在チェック
	 * @author shiraishitoshio
	 */
	public int countByFinData(String homeTeamName, String awayTeamName) {

		StringBuilder sql = new StringBuilder("""
				SELECT COUNT(*) AS cnt
				FROM static_data
				WHERE (
				    normalize(home_team_name, NFKC) = normalize(:homeTeamName, NFKC)
				    OR normalize(home_team_name, NFKC) LIKE normalize(:homeTeamNameContains, NFKC)
				    OR normalize(home_team_name, NFKC) LIKE normalize(:homeTeamNamePrefix, NFKC)
				    OR normalize(home_team_name, NFKC) LIKE normalize(:homeTeamNameSuffix, NFKC)
				)
				AND (
				    normalize(away_team_name, NFKC) = normalize(:awayTeamName, NFKC)
				    OR normalize(away_team_name, NFKC) LIKE normalize(:awayTeamNameContains, NFKC)
				    OR normalize(away_team_name, NFKC) LIKE normalize(:awayTeamNamePrefix, NFKC)
				    OR normalize(away_team_name, NFKC) LIKE normalize(:awayTeamNameSuffix, NFKC)
				)
				AND times IS NOT NULL
				AND TRIM(times) <> ''
				AND REPLACE(TRIM(normalize(times, NFKC)), ' ', '') = '終了済'
				AND REPLACE(TRIM(normalize(times, NFKC)), ' ', '') NOT LIKE '%ペナルティ%'
				""");

		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("homeTeamName", homeTeamName);
		params.addValue("homeTeamNameContains", "%" + escapeLike(homeTeamName) + "%");
		params.addValue("homeTeamNamePrefix", escapeLike(homeTeamName) + "%");
		params.addValue("homeTeamNameSuffix", "%" + escapeLike(homeTeamName));

		params.addValue("awayTeamName", awayTeamName);
		params.addValue("awayTeamNameContains", "%" + escapeLike(awayTeamName) + "%");
		params.addValue("awayTeamNamePrefix", escapeLike(awayTeamName) + "%");
		params.addValue("awayTeamNameSuffix", "%" + escapeLike(awayTeamName));

		Integer count = bmJdbcTemplate.queryForObject(
				sql.toString(),
				params,
				Integer.class);

		return count != null ? count : 0;
	}

	/**
	 * 現在進行中(リアルタイム)のLIVEデータの件数・最終更新時刻を取得する。
	 * timesが「終了済/ペナルティ」以外であることに加え、
	 * record_time(＝実データの記録時刻。update_timeではない)が
	 * 直近(withinで指定した期間)以内に更新されているものだけを
	 * 「今まさにライブ」とみなす。
	 *
	 * lastUpdatedAt は cnt のしきい値(within)とは関係なく、
	 * 「非終了状態のデータとして記録された、本当の最終更新時刻」を常に返す。
	 * これにより、直近withinを過ぎて cnt=0 になった場合でも、
	 * 「過去に更新実績があるが、直近では更新が止まっている（＝実質終了済とみなせる）」のか、
	 * 「そもそも一度もデータが来ていない」のかを呼び出し側で区別できる。
	 * @author shiraishitoshio
	 */
	public CurrentLiveDataResult findCurrentLiveData(String homeTeamName, String awayTeamName, Duration within) {

		Timestamp threshold = RecordTimeConvertUtil.freshnessThreshold(within);

		StringBuilder sql = new StringBuilder("""
				SELECT
				    COUNT(*) FILTER (WHERE record_time >= :threshold) AS cnt,
				    MAX(record_time) AS last_updated_at
				FROM static_data
				WHERE normalize(home_team_name, NFKC) = normalize(:homeTeamName, NFKC)
				AND normalize(away_team_name, NFKC) = normalize(:awayTeamName, NFKC)
				AND times IS NOT NULL
				AND TRIM(times) <> ''
				AND REPLACE(TRIM(normalize(times, NFKC)), ' ', '') <> '終了済'
				AND REPLACE(TRIM(normalize(times, NFKC)), ' ', '') NOT LIKE '%ペナルティ%'
				AND record_time IS NOT NULL
				""");

		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("homeTeamName", homeTeamName);
		params.addValue("awayTeamName", awayTeamName);
		params.addValue("threshold", threshold);

		return bmJdbcTemplate.queryForObject(sql.toString(), params, (rs, rowNum) -> {
			CurrentLiveDataResult r = new CurrentLiveDataResult();
			r.count = rs.getInt("cnt");
			r.lastUpdatedAt = RecordTimeConvertUtil.readAsJst(rs, "last_updated_at");
			return r;
		});
	}

	public static class CurrentLiveDataResult {
		public int count;
		public OffsetDateTime lastUpdatedAt;
	}

	/**
	 * LIKE検索用にワイルドカード文字(%, _, \)をエスケープする
	 * PostgreSQLのLIKEはデフォルトのエスケープ文字が「\」のため、
	 * ESCAPE句を省略してもそのまま機能する。
	 */
	private String escapeLike(String value) {
		if (value == null) {
			return null;
		}
		return value.replace("\\", "\\\\")
				.replace("%", "\\%")
				.replace("_", "\\_");
	}

	@EqualsAndHashCode
	public static class BusinessGroupCountRow {
		public String conditionResultDataSeqId;
		public String dataCategory;
		public String homeTeamName;
		public String awayTeamName;
		public String formattedDataCategory;
		public String categoryFormatIcon;
		public long cnt;
	}

	// matchKey（= match_id）ごとの times 一覧（昇順、終了済は最後）
	public Map<String, List<String>> findDistinctTimesByMatchKeys(List<String> keys) {
		if (keys == null || keys.isEmpty())
			return Map.of();

		String sql = """
				WITH base AS (
				  SELECT
				    COALESCE(
				      NULLIF(BTRIM(d.match_id), ''),
				      NULLIF((regexp_match(d.game_link, 'mid=([A-Za-z0-9]+)'))[1], ''),
				      NULLIF(BTRIM(d.game_id), '')
				    ) AS match_key,
				    NULLIF(BTRIM(d.times), '') AS times
				  FROM public.static_data d
				  WHERE COALESCE(
				      NULLIF(BTRIM(d.match_id), ''),
				      NULLIF((regexp_match(d.game_link, 'mid=([A-Za-z0-9]+)'))[1], ''),
				      NULLIF(BTRIM(d.game_id), '')
				    ) IN (:keys)
				),
				dedup AS (
				  SELECT DISTINCT
				    match_key,
				    times,
				    CASE
				      WHEN times = '終了済' OR times LIKE '%ペナルティ%' THEN 99999999
				      WHEN times ~ '^[0-9]{1,3}:[0-9]{1,2}$'
				        THEN (split_part(times, ':', 1)::int * 60 + split_part(times, ':', 2)::int)
				      WHEN times ~ '^[0-9]{1,3}''$'
				        THEN (replace(times, '''', '')::int * 60)
				      ELSE 99999998
				    END AS sort_key
				  FROM base
				  WHERE match_key IS NOT NULL AND match_key <> ''
				    AND times IS NOT NULL AND times <> ''
				)
				SELECT match_key, array_agg(times ORDER BY sort_key, times) AS times_list
				FROM dedup
				GROUP BY match_key;
				""";

		var params = new MapSqlParameterSource().addValue("keys", keys);

		List<Map.Entry<String, List<String>>> rows = bmJdbcTemplate.query(sql, params, (rs, rowNum) -> {
			String k = rs.getString("match_key");
			java.sql.Array arr = rs.getArray("times_list");
			String[] xs = (arr == null) ? new String[0] : (String[]) arr.getArray();
			return Map.entry(k, List.of(xs));
		});

		Map<String, List<String>> out = new java.util.HashMap<>();
		for (var e : rows)
			out.put(e.getKey(), e.getValue());
		return out;
	}

	/**
	 * 全取得用: dataCategory × home_team_name × away_team_name でグルーピングした件数を取得。
	 * home/away の組み合わせ単位で、dataCategory の形式が揃っているかどうかの
	 * アイコン文字列(同一カテゴリ名 / 混在)を付与する。
	 */
	public List<RealTimeDataDTO> findAllGrouping() {

		String sql = """
				WITH classified AS (
				    SELECT
				        data_category,
				        home_team_name,
				        away_team_name,
				        %s AS category_format
				    FROM static_data
				),
				grouped AS (
				    SELECT
				        data_category,
				        home_team_name,
				        away_team_name,
				        category_format,
				        COUNT(*) AS cnt
				    FROM classified
				    GROUP BY data_category, home_team_name, away_team_name, category_format
				),
				format_consistency AS (
				    SELECT
				        home_team_name,
				        away_team_name,
				        CASE
				            WHEN COUNT(DISTINCT COALESCE(category_format, '__NONE__')) = 1
				            THEN '同一カテゴリ名'
				            ELSE '混在'
				        END AS category_format_icon
				    FROM classified
				    GROUP BY home_team_name, away_team_name
				)
				SELECT
				    g.data_category,
				    CASE WHEN g.category_format IS NOT NULL THEN g.data_category ELSE NULL END AS formatted_data_category,
				    g.home_team_name,
				    g.away_team_name,
				    g.cnt,
				    fc.category_format_icon
				FROM grouped g
				JOIN format_consistency fc
				    ON g.home_team_name = fc.home_team_name
				   AND g.away_team_name = fc.away_team_name
				"""
				.formatted(CATEGORY_FORMAT_CASE);

		return bmJdbcTemplate.query(sql, new MapSqlParameterSource(), (rs, rowNum) -> {
			RealTimeDataDTO dto = new RealTimeDataDTO();
			dto.setDataCategory(rs.getString("data_category"));
			dto.setFormattedDataCategory(rs.getString("formatted_data_category"));
			dto.setHomeTeamName(rs.getString("home_team_name"));
			dto.setAwayTeamName(rs.getString("away_team_name"));
			dto.setCnt(rs.getLong("cnt"));
			dto.setCategoryFormatIcon(rs.getString("category_format_icon"));
			return dto;
		});
	}

	/**
	 * search用: 指定した home/away チーム名 (NFKC正規化して比較) に紐づく
	 * data_category を1件取得する。同じ home/away の組み合わせに紐づく
	 * data_category 全体の形式が揃っているかどうかのアイコン文字列も付与する。
	 */
	public List<BusinessGroupCountRow> findAllByDataCategory(String homeTeamName, String awayTeamName) {

		String sql = """
				WITH classified AS (
				    SELECT
				        data_category,
				        home_team_name,
				        away_team_name,
				        %s AS category_format
				    FROM static_data
				    WHERE normalize(home_team_name, NFKC) = normalize(:homeTeamName, NFKC)
				      AND normalize(away_team_name, NFKC) = normalize(:awayTeamName, NFKC)
				),
				format_consistency AS (
				    SELECT
				        CASE
				            WHEN COUNT(DISTINCT COALESCE(category_format, '__NONE__')) = 1
				            THEN '同一カテゴリ名'
				            ELSE '混在'
				        END AS category_format_icon
				    FROM classified
				)
				SELECT
				    c.data_category,
				    CASE WHEN c.category_format IS NOT NULL THEN c.data_category ELSE NULL END AS formatted_data_category,
				    c.home_team_name,
				    c.away_team_name,
				    fc.category_format_icon
				FROM classified c
				CROSS JOIN format_consistency fc
				LIMIT 1
				"""
				.formatted(CATEGORY_FORMAT_CASE);

		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("homeTeamName", homeTeamName);
		params.addValue("awayTeamName", awayTeamName);

		return bmJdbcTemplate.query(sql, params, (rs, rowNum) -> {
			BusinessGroupCountRow r = new BusinessGroupCountRow();
			r.dataCategory = rs.getString("data_category");
			r.formattedDataCategory = rs.getString("formatted_data_category");
			r.homeTeamName = rs.getString("home_team_name");
			r.awayTeamName = rs.getString("away_team_name");
			r.categoryFormatIcon = rs.getString("category_format_icon");
			return r;
		});
	}

	/**
	 * 更新: 指定した home/away チーム名(NFKC正規化して比較)に紐づく static_data の
	 * dataCategory を、同一 home/away の組み合わせを持つ行すべてに対して新しい値で上書きする。
	 *
	 * @param homeTeamName 更新対象を絞り込むホームチーム名
	 * @param awayTeamName 更新対象を絞り込むアウェーチーム名
	 * @param newDataCategory 上書き後の dataCategory
	 * @return 更新された行数(同一 home/away の組み合わせを持つ行が複数あれば2件以上になり得る)
	 */
	public int updateNewDataCategory(String homeTeamName, String awayTeamName, String newDataCategory) {

		String sql = """
				UPDATE static_data
				SET
					data_category = :newDataCategory,
					update_time = CURRENT_TIMESTAMP
				WHERE normalize(home_team_name, NFKC) = normalize(:homeTeamName, NFKC)
				  AND normalize(away_team_name, NFKC) = normalize(:awayTeamName, NFKC)
				""";

		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("homeTeamName", homeTeamName);
		params.addValue("awayTeamName", awayTeamName);
		params.addValue("newDataCategory", newDataCategory);

		return bmJdbcTemplate.update(sql, params);
	}

	/**
	 * home_team_name / away_team_name (NFKC正規化) 単位で、
	 * data_category が「終了済」の行が1件も存在しない組み合わせの
	 * match_id / home_team_name / away_team_name を取得
	 * @author shiraishitoshio
	 */
	public List<MatchTeamRow> findMatchIdsWithoutFinishedCategoryByTeams() {
		String sql = """
				SELECT DISTINCT
				  d.match_id,
				  d.home_team_name,
				  d.away_team_name
				FROM static_data d
				WHERE d.match_id IS NOT NULL
				  AND TRIM(d.match_id) <> ''
				  AND NOT EXISTS (
				        SELECT 1
				        FROM static_data d2
				        WHERE normalize(d2.home_team_name, NFKC) = normalize(d.home_team_name, NFKC)
				          AND normalize(d2.away_team_name, NFKC) = normalize(d.away_team_name, NFKC)
				          AND REPLACE(TRIM(normalize(d2.data_category, NFKC)), ' ', '') = '終了済'
				  )
				""";
		return bmJdbcTemplate.query(sql, new MapSqlParameterSource(), (rs, rowNum) -> {
			MatchTeamRow r = new MatchTeamRow();
			r.matchId = rs.getString("match_id");
			r.homeTeamName = rs.getString("home_team_name");
			r.awayTeamName = rs.getString("away_team_name");
			return r;
		});
	}

	/**
	 * 指定されたmatch_id一覧に該当するデータを取得する。
	 * static_dataは件数が多いため、country/leagueのLIKE検索で全件走査するのではなく、
	 * 呼び出し側で対象を絞り込んだmatch_id一覧（例: S3上に実在するzipのmatchId一覧）に対して
	 * ピンポイントで取得する用途に使う。
	 * country/league/finFlgによる絞り込みは行わないため、必要であれば呼び出し側で
	 * 取得結果のdataCategory・timesを見て判定すること。
	 *
	 * @param matchIds 対象のmatch_id一覧
	 * @return 該当データ一覧（match_id・data_category・times・home/away team name含む、空ならから配列）
	 */
	public List<DataIngestRow> findByMatchIds(Collection<String> matchIds) {
		if (matchIds == null || matchIds.isEmpty()) {
			return List.of();
		}
		String sql = """
				SELECT
				    d.seq_key,
				    d.data_category,
				    d.times,
				    d.match_id,
				    d.home_team_name,
				    d.away_team_name
				FROM static_data d
				WHERE d.match_id IN (:matchIds)
				""";
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("matchIds", matchIds);
		return bmJdbcTemplate.query(sql, params, (rs, rowNum) -> {
			DataIngestRow r = new DataIngestRow();
			r.seq = rs.getString("seq_key");
			r.dataCategory = rs.getString("data_category");
			r.times = rs.getString("times");
			r.matchId = rs.getString("match_id");
			r.homeTeamName = rs.getString("home_team_name");
			r.awayTeamName = rs.getString("away_team_name");
			return r;
		});
	}

	/**
	 * 指定されたmatch_id一覧のうち、times が「終了済」の行が1件でも存在する
	 * match_id の集合を取得する。
	 * <p>
	 * 1つのmatch_idに対して試合経過ごとに複数のstatic_data行（times違い）が
	 * 存在し得るため、findByMatchIdsで1行（最新のseq_key）だけに絞って判定すると、
	 * その1行がたまたま「終了済」以外だった場合に誤って「対戦中」と判定されてしまう。
	 * この誤判定を避けるため、match_id単位で「終了済」行の有無を別クエリで判定する。
	 * </p>
	 * @param matchIds 対象のmatch_id一覧
	 * @return 「終了済」の行が1件以上存在するmatch_idの集合
	 */
	public Set<String> findFinishedMatchIds(Collection<String> matchIds) {
		if (matchIds == null || matchIds.isEmpty()) {
			return Set.of();
		}
		String sql = """
				SELECT DISTINCT d.match_id
				FROM static_data d
				WHERE d.match_id IN (:matchIds)
				  AND d.times IS NOT NULL
				  AND TRIM(d.times) <> ''
				  AND REPLACE(TRIM(normalize(d.times, NFKC)), ' ', '') = '終了済'
				""";
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("matchIds", matchIds);
		List<String> rows = bmJdbcTemplate.query(sql, params, (rs, rowNum) -> rs.getString("match_id"));
		return new HashSet<>(rows);
	}

	public static class MatchTeamRow {
		public String matchId;
		public String homeTeamName;
		public String awayTeamName;
	}

}