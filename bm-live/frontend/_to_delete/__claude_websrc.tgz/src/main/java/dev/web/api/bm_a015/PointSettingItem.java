package dev.web.api.bm_a015;

import lombok.Data;

@Data
public class PointSettingItem {

	/** 国 */
    private String country;

    /** リーグ */
    private String league;

    /** 勝ち */
    private Integer win;

    /** 負け */
    private Integer lose;

    /** 引き分け */
    private Integer draw;

    /**
     * 備考
     * null / 空文字は許可
     * 入力する場合のみ: PK勝ち=X,PK負け=Y
     */
	@ValidPointSettingRemarks
    private String remarks;

    /** 削除フラグ */
    private String delFlg;

}
