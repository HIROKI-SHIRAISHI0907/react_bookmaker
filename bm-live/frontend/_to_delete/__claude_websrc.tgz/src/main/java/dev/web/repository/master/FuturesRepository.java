package dev.web.repository.master;

import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import dev.common.util.DateOffsetDecisionUtil;
import lombok.Data;

/**
 * FuturesRepositoryクラス
 * ※ future_time を timestamp without time zone（JST壁時計）として扱う前提
 *
 * <p>2026-10 追加: findByFutureDate / countByFutureDate（指定日の試合予定一覧: bm_a030）</p>
 * @author shiraishitoshio
 *
 */
@Repository
public class FuturesRepository {

	private final NamedParameterJdbcTemplate masterJdbcTemplate;

	public FuturesRepository(
			@Qualifier("webMasterJdbcTemplate") NamedParameterJdbcTemplate masterJdbcTemplate) {
		this.masterJdbcTemplate = masterJdbcTemplate;
	}

	// --------------------------------------------------------
	// 一覧: GET /api/future/:country/:league/:team（チーム取得）
	// --------------------------------------------------------
	public String findTeamJa(String country, String league, String teamSlug) {
		String sql = """
				SELECT team
				FROM country_league_master
				WHERE country = :country
				  AND league  = :league
				  AND link LIKE :link
				LIMIT 1
				""";

		MapSqlParameterSource params = new MapSqlParameterSource()
				.addValue("country", country)
				.addValue("league", league)
				.addValue("link", "/team/" + teamSlug + "/%");

		List<String> results = masterJdbcTemplate.query(
				sql,
				params,
				(rs, rowNum) -> rs.getString("team"));

		return results.isEmpty() ? teamSlug : results.get(0);
	}


	public List<FutureMatchRow> findByIds(List<Long> ids) {
		if (ids == null || ids.isEmpty()) {
			return List.of();
		}

		String sql = """
				SELECT
				  seq AS id,
				  home_team_name,
				  away_team_name,
				  future_time
				FROM future_master
				WHERE seq IN (:ids)
				""";

		return masterJdbcTemplate.query(sql, Map.of("ids", ids), (rs, rowNum) -> {
			FutureMatchRow r = new FutureMatchRow();
			r.id = rs.getLong("id");
			r.homeTeamName = rs.getString("home_team_name");
			r.awayTeamName = rs.getString("away_team_name");

			OffsetDateTime ft = DateOffsetDecisionUtil.getOffsetDateTime(rs, "future_time");
			r.matchStartTime = DateOffsetDecisionUtil.toOffsetDateTimeJst(ft);

			return r;
		});
	}


	// ========= future_master =========
	public List<FutureMasterIngestRow> findFutureMasterByRegisterTime(String country, String team) {
		StringBuilder sql = new StringBuilder("""
				SELECT
					seq,
					game_team_category,
					future_time,
					home_team_name,
					away_team_name,
					game_link,
					start_flg
				FROM future_master
				WHERE 1 = 1
				""");

		MapSqlParameterSource params = new MapSqlParameterSource();

		if (country != null && !country.isBlank()) {
			sql.append("""
					AND game_team_category LIKE :countryLike
					""");
			params.addValue("countryLike", country.trim() + ":%");
		}

		if (team != null && !team.isBlank()) {
			sql.append("""
					AND
					(
						normalize(home_team_name, NFKC) = normalize(:homeTeamName, NFKC)
					OR
						normalize(away_team_name, NFKC) = normalize(:awayTeamName, NFKC)
					)
					""");
			params.addValue("homeTeamName", team);
			params.addValue("awayTeamName", team);
		}

		sql.append("""
				ORDER BY future_time ASC, seq ASC
				""");

		return masterJdbcTemplate.query(sql.toString(), params, (rs, rowNum) -> {
			FutureMasterIngestRow r = new FutureMasterIngestRow();
			r.seq = rs.getLong("seq");
			r.gameTeamCategory = rs.getString("game_team_category");

			OffsetDateTime ft = DateOffsetDecisionUtil.getOffsetDateTime(rs, "future_time");
			r.futureTime = DateOffsetDecisionUtil.toIsoJstString(ft);

			r.homeTeamName = rs.getString("home_team_name");
			r.awayTeamName = rs.getString("away_team_name");
			r.gameLink = rs.getString("game_link");
			r.startFlg = rs.getString("start_flg");

			return r;
		});
	}

	/**
	 * 互換用オーバーロード
	 */
	public List<FutureMasterIngestRow> findFutureMasterByRegisterTime(String country, String keyword,
			String team) {
		return findFutureMasterByRegisterTime(country, team);
	}

	// ========= 指定日の試合予定一覧（bm_a030） =========

	/** 指定日（日本時間 0:00〜翌 0:00）の条件。future_time は timestamptz なので、日本時間の 0:00 を timestamptz に直して比べる（接続のタイムゾーンに左右されない） */
	private static final String FUTURE_DATE_WHERE = """
			WHERE f.future_time >= (CAST(:date AS timestamp) AT TIME ZONE 'Asia/Tokyo')
			  AND f.future_time <  ((CAST(:date AS timestamp) + INTERVAL '1 day') AT TIME ZONE 'Asia/Tokyo')
			""";

	/**
	 * 指定日の試合予定を、試合開始日時順に1ページ分取得する。
	 *
	 * @param date 対象日（日本時間）
	 * @param offset 取得開始位置
	 * @param limit 取得件数
	 */
	public List<FutureMatchDateRow> findByFutureDate(LocalDate date, int offset, int limit) {
		String sql = """
				SELECT
				  f.seq,
				  f.game_team_category,
				  f.future_time,
				  to_char(f.future_time AT TIME ZONE 'Asia/Tokyo', 'YYYY-MM-DD HH24:MI:SS') AS future_time_local,
				  f.home_team_name,
				  f.away_team_name,
				  NULLIF(BTRIM(f.game_link), '') AS game_link,
				  (regexp_match(f.game_link, 'mid=([A-Za-z0-9]+)'))[1] AS mid,
				  CAST((regexp_match(f.game_team_category, '(ラウンド|Round)\\s*([0-9]+)'))[2] AS INT) AS round_no,
				  f.start_flg
				FROM future_master f
				%s
				ORDER BY f.future_time ASC, f.seq ASC
				OFFSET :offset
				LIMIT :limit
				""".formatted(FUTURE_DATE_WHERE);

		MapSqlParameterSource params = new MapSqlParameterSource()
				.addValue("date", date.toString())
				.addValue("offset", offset)
				.addValue("limit", limit);

		return masterJdbcTemplate.query(sql, params, (rs, rowNum) -> {
			FutureMatchDateRow r = new FutureMatchDateRow();
			r.setSeq(rs.getLong("seq"));
			r.setGameTeamCategory(rs.getString("game_team_category"));

			OffsetDateTime ft = DateOffsetDecisionUtil.getOffsetDateTime(rs, "future_time");
			r.setFutureTime(DateOffsetDecisionUtil.toIsoJstString(ft));
			r.setFutureTimeLocal(rs.getString("future_time_local"));

			r.setHomeTeamName(rs.getString("home_team_name"));
			r.setAwayTeamName(rs.getString("away_team_name"));
			r.setGameLink(rs.getString("game_link"));
			r.setMid(rs.getString("mid"));

			int roundNo = rs.getInt("round_no");
			r.setRoundNo(rs.wasNull() ? null : roundNo);

			r.setStartFlg(rs.getString("start_flg"));
			return r;
		});
	}

	/** 指定日の試合予定の件数 */
	public long countByFutureDate(LocalDate date) {
		String sql = """
				SELECT COUNT(*)
				FROM future_master f
				%s
				""".formatted(FUTURE_DATE_WHERE);

		Long cnt = masterJdbcTemplate.queryForObject(sql,
				new MapSqlParameterSource().addValue("date", date.toString()), Long.class);
		return cnt == null ? 0L : cnt;
	}

	// row classes
	public static class FutureMasterIngestRow {
		public Long seq;
		public String gameTeamCategory;
		public String futureTime;
		public String homeTeamName;
		public String awayTeamName;
		public String gameLink;
		public String startFlg;
	}

	public static class FutureMatchRow {
		public Long id;
		public String homeTeamName;
		public String awayTeamName;
		public OffsetDateTime matchStartTime;
	}

	/** 指定日の試合予定1行（bm_a030） */
	@Data
	public static class FutureMatchDateRow {
		private Long seq;
		private String gameTeamCategory;
		/** 試合開始日時（ISO・+09:00） */
		private String futureTime;
		/** 試合開始日時（"yyyy-MM-dd HH:mm:ss"・日本時間。static_data との突き合わせ用） */
		private String futureTimeLocal;
		private String homeTeamName;
		private String awayTeamName;
		private String gameLink;
		/** game_link の mid（無ければ null） */
		private String mid;
		private Integer roundNo;
		private String startFlg;
	}

	// ========= 各得点失点存在確認用 =========
	/**
	 * 各チームの試合候補（future_master）を返す
	 * - 対象: start_flg=1, future_time not null, チーム一致
	 * - リーグ: likeCond で絞る
	 * - 重複: (home, away, round_no) で DISTINCT
	 */
	public List<DataEachScoreLostDataResponseDTO> findEachScoreLoseMatchesExistsList(
			String country, String league, String teamJa) {

		String likeCond = country + ": " + league + "%";

		String sql = """
				WITH base AS (
				  SELECT
				    f.seq,
				    f.game_team_category AS data_category,
				    f.future_time        AS record_time,
				    f.home_team_name     AS home_team_name,
				    f.away_team_name     AS away_team_name,
				    NULLIF(BTRIM(f.game_link), '') AS link,
				    (regexp_match(f.game_link, 'mid=([A-Za-z0-9]+)'))[1] AS mid,
				    CASE
				      WHEN regexp_match(f.game_team_category, '(ラウンド|Round)\\\\s*([0-9]+)') IS NULL THEN NULL
				      ELSE CAST((regexp_match(f.game_team_category, '(ラウンド|Round)\\\\s*([0-9]+)'))[2] AS INT)
				    END AS round_no,
				    COALESCE(f.update_time, f.register_time, f.data_time, f.future_time) AS ut
				  FROM future_master f
				  WHERE f.start_flg = '1'
				    AND f.future_time IS NOT NULL
				    AND (f.home_team_name = :teamJa OR f.away_team_name = :teamJa)
				    AND f.game_team_category LIKE :likeCond
				    AND f.game_link IS NOT NULL
				    AND f.game_link ~ 'mid='
				),
				picked AS (
				  SELECT DISTINCT ON (mid)
				    seq, data_category, record_time, home_team_name, away_team_name, link, mid, round_no
				  FROM base
				  WHERE mid IS NOT NULL AND mid <> ''
				  ORDER BY mid, ut DESC, seq DESC
				)
				SELECT *
				FROM picked
				ORDER BY round_no DESC
				""";

		var params = new MapSqlParameterSource()
				.addValue("teamJa", teamJa)
				.addValue("likeCond", likeCond);

		RowMapper<DataEachScoreLostDataResponseDTO> rm = (ResultSet rs, int rowNum) -> {
			var dto = new DataEachScoreLostDataResponseDTO();
			dto.setSeq(rs.getLong("seq"));
			dto.setDataCategory(rs.getString("data_category"));

			int roundNo = rs.getInt("round_no");
			dto.setRoundNo(rs.wasNull() ? null : String.valueOf(roundNo));

			OffsetDateTime rt = DateOffsetDecisionUtil.getOffsetDateTime(rs, "record_time");
			dto.setRecordTime(DateOffsetDecisionUtil.toIsoJstString(rt));

			dto.setHomeTeamName(rs.getString("home_team_name"));
			dto.setAwayTeamName(rs.getString("away_team_name"));
			dto.setLink(rs.getString("link"));
			return dto;
		};

		return masterJdbcTemplate.query(sql, params, rm);
	}

	@Data
	public class DataEachScoreLostDataResponseDTO {
		private Long seq;
		private String dataCategory;
		private String roundNo;
		private String recordTime;
		private String homeTeamName;
		private String awayTeamName;
		private Integer homeScore;
		private Integer awayScore;
		private String link;
	}

	// 過去の試合予定日用キックオフ時間取得
	public Map<String, String> findFutureTimeByGameLinks(String country, String league, List<String> links) {
		if (links == null || links.isEmpty()) {
			return Map.of();
		}

		String likeCond = country + ": " + league + "%";

		String sql = """
				SELECT DISTINCT ON (NULLIF(BTRIM(f.game_link), ''))
				  NULLIF(BTRIM(f.game_link), '') AS game_link,
				  f.future_time
				FROM future_master f
				WHERE f.start_flg = '1'
				  AND f.game_team_category LIKE :likeCond
				  AND NULLIF(BTRIM(f.game_link), '') IN (:links)
				ORDER BY NULLIF(BTRIM(f.game_link), ''), COALESCE(f.update_time, f.register_time) DESC, f.seq DESC
				""";

		var params = new MapSqlParameterSource()
				.addValue("likeCond", likeCond)
				.addValue("links", links);

		return masterJdbcTemplate.query(sql, params, (ResultSet rs) -> {
			java.util.Map<String, String> out = new java.util.HashMap<>();
			while (rs.next()) {
				String link = rs.getString("game_link");
				OffsetDateTime ft = DateOffsetDecisionUtil.getOffsetDateTime(rs, "future_time");
				if (link == null || link.isBlank() || ft == null) {
					continue;
				}
				out.put(link, DateOffsetDecisionUtil.toIsoJstString(ft));
			}
			return out;
		});
	}

	// “matchKey” を game_link から抽出
	public java.util.Set<String> findExistingMatchKeys(List<String> keys) {
		if (keys == null || keys.isEmpty()) {
			return java.util.Set.of();
		}

		String sql = """
				WITH base AS (
				  SELECT
				    COALESCE(
				      NULLIF((regexp_match(f.game_link, 'mid=([A-Za-z0-9]+)'))[1], ''),
				      NULLIF(BTRIM(f.game_link), '')
				    ) AS match_key
				  FROM future_master f
				  WHERE f.game_link IS NOT NULL
				)
				SELECT DISTINCT match_key
				FROM base
				WHERE match_key IN (:keys)
				""";

		var params = new MapSqlParameterSource().addValue("keys", keys);
		List<String> xs = masterJdbcTemplate.query(sql, params, (rs, rowNum) -> rs.getString("match_key"));
		return new java.util.HashSet<>(xs);
	}

	// 「matchKey(mid)→game_link」取得メソッド
	public Map<String, String> findGameLinksByMatchKeys(List<String> keys) {
		if (keys == null || keys.isEmpty()) {
			return Map.of();
		}

		String sql = """
				WITH base AS (
				  SELECT
				    (regexp_match(f.game_link, 'mid=([A-Za-z0-9]+)'))[1] AS mid,
				    NULLIF(BTRIM(f.game_link), '') AS game_link,
				    COALESCE(f.update_time, f.register_time) AS ut,
				    f.seq AS seq
				  FROM future_master f
				  WHERE f.game_link IS NOT NULL
				    AND f.game_link ~ 'mid='
				),
				picked AS (
				  SELECT DISTINCT ON (mid)
				    mid, game_link
				  FROM base
				  WHERE mid IN (:keys)
				  ORDER BY mid, ut DESC, seq DESC
				)
				SELECT mid, game_link
				FROM picked
				""";

		var params = new MapSqlParameterSource().addValue("keys", keys);

		List<Map.Entry<String, String>> rows = masterJdbcTemplate.query(sql, params,
				(rs, rowNum) -> Map.entry(rs.getString("mid"), rs.getString("game_link")));

		Map<String, String> out = new java.util.HashMap<>();
		for (var e : rows) {
			if (e.getKey() != null && e.getValue() != null) {
				out.put(e.getKey(), e.getValue());
			}
		}
		return out;
	}

	/**
	 * 更新: 指定した home/away チーム名(NFKC正規化して比較)に紐づく future_master の
	 * dataCategory を、同一 home/away の組み合わせを持つ行すべてに対して新しい値で上書きする。
	 *
	 * @param homeTeamName 更新対象を絞り込むホームチーム名
	 * @param awayTeamName 更新対象を絞り込むアウェーチーム名
	 * @param newDataCategory 上書き後の dataCategory
	 * @return 更新された行数(同一 home/away の組み合わせを持つ行が複数あれば2件以上になり得る)
	 */
	public int updateNewDataCategory(String homeTeamName, String awayTeamName, String newDataCategory) {

		String sql = """
				UPDATE future_master
				SET
					game_team_category = :newDataCategory,
					update_time = CURRENT_TIMESTAMP
				WHERE normalize(home_team_name, NFKC) = normalize(:homeTeamName, NFKC)
				  AND normalize(away_team_name, NFKC) = normalize(:awayTeamName, NFKC)
				""";

		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("homeTeamName", homeTeamName);
		params.addValue("awayTeamName", awayTeamName);
		params.addValue("newDataCategory", newDataCategory);

		return masterJdbcTemplate.update(sql, params);
	}

}
