package dev.common.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * output_通番.xlsxブックから読み込んだデータをマッピングさせるためのDTOクラス
 * @author shiraishitoshio
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class CountryLeagueMasterEntity extends MetaEntity {

	/** ID */
	private Integer id;

	/** 国 */
	private String country;

	/** リーグ */
	private String league;

	/** サブリーグ */
	private String subLeague;

	/** チーム */
	private String team;

	/** リンク */
	private String link;

	/** 削除フラグ */
	private String delFlg;

}
