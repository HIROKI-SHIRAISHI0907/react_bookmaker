package dev.batch.bm_b002;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dev.batch.repository.master.TeamMemberMasterBatchRepository;
import dev.common.config.PathConfig;
import dev.common.entity.TeamMemberMasterEntity;
import dev.common.logger.ManageLoggerComponent;
import dev.common.s3.S3Operator;
import dev.common.util.DateOffsetDecisionUtil;
import dev.common.util.FileDeleteUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 選手登録・更新ロジック（B002）
 *
 * <p>2026-10 修正（ヘッダしかない CSV が S3 に残り続ける問題）</p>
 * <ul>
 *   <li>削除対象のファイルを、呼び出し側から渡された全ファイル（ヘッダのみを含む）＋入力の全行のファイルにした。
 *       以前は「同一入力内の重複をまとめた後に残った行」のファイルだけを削除していたため、
 *       ヘッダのみのファイルや、行がすべて他のファイルの行にまとめられたファイルが削除されずに残っていた。</li>
 *   <li>{@link #deleteProcessedFiles(Collection)}: 登録する選手がいない場合（全ファイルがヘッダのみ）に、削除だけ行う。</li>
 * </ul>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TeamMemberMasterStat {

	/** プロジェクト名 */
	private static final String PROJECT_NAME = TeamMemberMasterStat.class.getProtectionDomain()
			.getCodeSource().getLocation().getPath();

	/** クラス名 */
	private static final String CLASS_NAME = TeamMemberMasterStat.class.getName();

	private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	/**
	 * 何回連続で未検出なら引退扱いにするか
	 */
	private static final int RETIRE_MISSING_THRESHOLD = 3;

	private final TeamMemberMasterBatchRepository repository;

	/** Config */
	@Autowired
	private PathConfig config;

	/** S3Operator */
	@Autowired
	private S3Operator s3Operator;

	/** ログ管理クラス */
	@Autowired
	private ManageLoggerComponent manageLoggerComponent;

	/**
	 * メインエントリ（互換用。削除対象は入力の各行のファイル）
	 *
	 * @param scrapedRows  今回スクレイピングした選手データ一覧
	 * @param fullSnapshot true: 対象全件を取り切れている → 引退判定を行う
	 *                     false: 部分取得 → 引退判定しない
	 */
	@Transactional
	public void execute(List<TeamMemberMasterEntity> scrapedRows, boolean fullSnapshot) {
		execute(scrapedRows, fullSnapshot, null);
	}

	/**
	 * メインエントリ
	 *
	 * @param scrapedRows  今回スクレイピングした選手データ一覧
	 * @param fullSnapshot true: 対象全件を取り切れている → 引退判定を行う
	 *                     false: 部分取得 → 引退判定しない
	 * @param fileKeys     今回読めた全ファイル（ヘッダのみのファイルを含む。null 可）。処理が最後まで終わったら削除する
	 */
	@Transactional
	public void execute(List<TeamMemberMasterEntity> scrapedRows, boolean fullSnapshot, Collection<String> fileKeys) {
		// 削除対象: 渡された全ファイル ＋ 入力の全行のファイル（重複をまとめる前に集める）
		Set<String> deleteTargets = new LinkedHashSet<>();
		if (fileKeys != null) {
			for (String k : fileKeys) {
				if (!isBlank(k)) {
					deleteTargets.add(k);
				}
			}
		}
		if (scrapedRows != null) {
			for (TeamMemberMasterEntity row : scrapedRows) {
				if (row != null && !isBlank(row.getFile())) {
					deleteTargets.add(row.getFile());
				}
			}
		}

		String runDate = LocalDate.now(DateOffsetDecisionUtil.getZoneId()).format(DATE_FMT);

		// 既存データ全件取得
		List<TeamMemberMasterEntity> existingList = repository.selectAll();
		BmB002TeamMemberMasterBean bean = new BmB002TeamMemberMasterBean(existingList);

		// 今回 seen した既存 id の集合
		Set<Integer> seenIds = new HashSet<>();

		// 新規データの前処理（同一入力内の重複マージ）
		List<TeamMemberMasterEntity> incomingList = dedupIncoming(scrapedRows, runDate);

		for (TeamMemberMasterEntity incoming : incomingList) {
			normalizeEntity(incoming, runDate);

			// ─── Step1: 同一チーム・同一人物の完全一致 ──────────────────────
			TeamMemberMasterEntity exact = bean.findExactCurrent(incoming);
			if (exact != null) {
				TeamMemberMasterEntity updated = mergeSameTeam(copyOf(exact), incoming, runDate);
				repository.updateById(updated);
				bean.putWorking(updated);
				seenIds.add(updated.getId());

				log.info("[同一所属更新] country={} / league={} / team={} / member={}",
						nvl(updated.getCountry()),
						nvl(updated.getLeague()),
						nvl(updated.getTeam()),
						nvl(updated.getMember()));
				continue;
			}

			// ─── Step2: team を無視して同一人物候補を特定 ─────────────────
			// ※ country 差異があっても same person と判断できるなら更新扱い
			TeamMemberMasterEntity samePerson = bean.resolveSamePerson(incoming);

			if (samePerson != null) {
				TeamMemberMasterEntity updated;

				if (!eq(samePerson.getTeam(), incoming.getTeam())) {
					// team 差異あり -> 移籍更新
					updated = applyTransfer(copyOf(samePerson), incoming, runDate);
					log.info("[移籍更新] member={} / country={}→{} / team={}→{}",
							nvl(incoming.getMember()),
							nvl(samePerson.getCountry()),
							nvl(incoming.getCountry()),
							nvl(samePerson.getTeam()),
							nvl(incoming.getTeam()));
				} else {
					// team 同一 -> league差異 / country差異 / 表記ゆれなどを更新
					updated = mergeSameTeam(copyOf(samePerson), incoming, runDate);
					log.info("[同一人物更新] member={} / country={}→{} / league={}→{} / team={}",
							nvl(incoming.getMember()),
							nvl(samePerson.getCountry()),
							nvl(incoming.getCountry()),
							nvl(samePerson.getLeague()),
							nvl(incoming.getLeague()),
							nvl(incoming.getTeam()));
				}

				repository.updateById(updated);
				bean.putWorking(updated);
				seenIds.add(updated.getId());
				continue;
			}

			// ─── Step3: 新規登録 ─────────────────────────────────────────
			// same person と判断できる材料が不足している場合のみ新規
			TeamMemberMasterEntity newEntity = buildNewEntity(incoming, runDate);
			repository.insert(newEntity);
			bean.putWorking(newEntity);

			if (!isBlank(newEntity.getId())) {
				seenIds.add(newEntity.getId());
			}

			log.info("[新規] country={} / league={} / team={} / member={}",
					nvl(newEntity.getCountry()),
					nvl(newEntity.getLeague()),
					nvl(newEntity.getTeam()),
					nvl(newEntity.getMember()));
		}

		// ─── Step4: 引退 / missing 判定 ──────────────────────────────────
		if (fullSnapshot) {
			for (TeamMemberMasterEntity existing : bean.getAllWorking()) {
				if (isBlank(existing.getId())) {
					continue;
				}
				if (seenIds.contains(existing.getId())) {
					continue;
				}

				TeamMemberMasterEntity missingUpdated = markMissingOrRetired(copyOf(existing));
				repository.updateById(missingUpdated);
				bean.putWorking(missingUpdated);

				if ("1".equals(missingUpdated.getRetireFlg())) {
					log.info("[引退確定] country={} / team={} / member={} / missingCount={}",
							nvl(missingUpdated.getCountry()),
							nvl(missingUpdated.getTeam()),
							nvl(missingUpdated.getMember()),
							nvl(missingUpdated.getMissingCount()));
				} else {
					log.info("[未検出] country={} / team={} / member={} / missingCount={}",
							nvl(missingUpdated.getCountry()),
							nvl(missingUpdated.getTeam()),
							nvl(missingUpdated.getMember()),
							nvl(missingUpdated.getMissingCount()));
				}
			}
		} else {
			log.info("fullSnapshot=false のため引退判定はスキップします");
		}

		// 途中で例外が起きなければ全てのファイル（ヘッダのみのファイルを含む）を削除する
		deleteProcessedFiles(deleteTargets);
	}

	/**
	 * 処理済みのファイルを S3 から削除する（2026-10 追加）。
	 * 登録する選手がいない場合（全ファイルがヘッダのみ）は、B002 からこれだけを呼ぶ。
	 *
	 * @param fileKeys 削除するファイル（S3 キー）
	 */
	public void deleteProcessedFiles(Collection<String> fileKeys) {
		final String METHOD_NAME = "deleteProcessedFiles";
		List<String> targets = new ArrayList<>();
		if (fileKeys != null) {
			for (String k : fileKeys) {
				if (!isBlank(k) && !targets.contains(k)) {
					targets.add(k);
				}
			}
		}
		if (targets.isEmpty()) {
			log.info("削除対象のファイルがありません");
			return;
		}
		log.info("処理済みファイルを削除します: {}件 {}", targets.size(), targets);
		String bucket = config.getS3BucketsTeamMemberData();
		FileDeleteUtil.deleteS3Files(
				targets,
				bucket,
				s3Operator,
				manageLoggerComponent,
				PROJECT_NAME,
				CLASS_NAME,
				METHOD_NAME,
				"TEAM_MEMBER");
	}

	// =========================================================================
	// 入力データの前処理
	// =========================================================================

	/**
	 * 新規入力の中で同一チーム・同一人物(currentKey)が重複する行を1件にまとめる
	 *
	 * ※ league 差異は同一人物の更新候補としてマージ
	 * ※ face/birth 等の強い識別子が無い場合のみ country を fallback に使う
	 */
	private List<TeamMemberMasterEntity> dedupIncoming(List<TeamMemberMasterEntity> scrapedRows, String runDate) {
		if (scrapedRows == null || scrapedRows.isEmpty()) {
			return new ArrayList<>();
		}

		Map<String, TeamMemberMasterEntity> map = new LinkedHashMap<>();

		for (TeamMemberMasterEntity row : scrapedRows) {
			normalizeEntity(row, runDate);

			String key = BmB002TeamMemberMasterBean.currentKey(row);
			if (!map.containsKey(key)) {
				map.put(key, row);
			} else {
				map.put(key, mergeIncomingDuplicate(map.get(key), row, runDate));
			}
		}

		return new ArrayList<>(map.values());
	}

	/**
	 * 入力内の重複行同士のマージ（新しい値を優先）
	 */
	private TeamMemberMasterEntity mergeIncomingDuplicate(TeamMemberMasterEntity a,
			TeamMemberMasterEntity b,
			String runDate) {

		TeamMemberMasterEntity out = copyOf(a);

		out.setCountry(firstNonBlank(b.getCountry(), a.getCountry()));
		out.setLeague(firstNonBlank(b.getLeague(), a.getLeague()));
		out.setTeam(firstNonBlank(b.getTeam(), a.getTeam()));
		out.setScore(mergeScore(a.getScore(), b.getScore()));
		out.setLoanBelong(mergeCsvDistinct(a.getLoanBelong(), b.getLoanBelong()));
		out.setJersey(firstNonBlank(b.getJersey(), a.getJersey()));
		out.setMember(firstNonBlank(b.getMember(), a.getMember()));
		out.setFacePicPath(preferFace(b.getFacePicPath(), a.getFacePicPath()));
		out.setBelongList(mergeCsvDistinct(a.getBelongList(), b.getBelongList()));
		out.setHeight(firstNonBlank(b.getHeight(), a.getHeight()));
		out.setWeight(firstNonBlank(b.getWeight(), a.getWeight()));
		out.setPosition(firstNonBlank(b.getPosition(), a.getPosition()));
		out.setBirth(firstNonBlank(b.getBirth(), a.getBirth()));
		out.setAge(firstNonBlank(b.getAge(), a.getAge()));
		out.setMarketValue(firstNonBlank(b.getMarketValue(), a.getMarketValue()));
		out.setInjury(firstNonBlank(b.getInjury(), a.getInjury()));
		out.setVersusTeamScoreData(firstNonBlank(b.getVersusTeamScoreData(), a.getVersusTeamScoreData()));
		out.setRetireFlg("0");
		out.setDeadline(firstNonBlank(b.getDeadline(), a.getDeadline()));
		out.setDeadlineContractDate(firstNonBlank(b.getDeadlineContractDate(), a.getDeadlineContractDate()));
		out.setLatestInfoDate(runDate);
		out.setMissingCount("0");

		return out;
	}

	// =========================================================================
	// 新規 / 更新 / 移籍 / missing 各処理
	// =========================================================================

	private TeamMemberMasterEntity buildNewEntity(TeamMemberMasterEntity incoming, String runDate) {
		TeamMemberMasterEntity e = copyOf(incoming);
		e.setBelongList(mergeBelongList(e.getBelongList(), e.getTeam()));
		e.setRetireFlg("0");
		e.setLatestInfoDate(runDate);
		e.setMissingCount("0");
		e.setDelFlg("0");
		return e;
	}

	/**
	 * 同一人物・同一チームの更新
	 *
	 * ※ country / league は incoming 優先
	 *    -> 国情報補正、昇格/降格、リーグ改称に追従
	 */
	private TeamMemberMasterEntity mergeSameTeam(TeamMemberMasterEntity existing,
			TeamMemberMasterEntity incoming,
			String runDate) {

		existing.setCountry(firstNonBlank(incoming.getCountry(), existing.getCountry()));
		existing.setLeague(firstNonBlank(incoming.getLeague(), existing.getLeague()));
		existing.setTeam(firstNonBlank(incoming.getTeam(), existing.getTeam()));
		existing.setScore(mergeScore(existing.getScore(), incoming.getScore()));
		existing.setLoanBelong(mergeCsvDistinct(existing.getLoanBelong(), incoming.getLoanBelong()));
		existing.setJersey(firstNonBlank(incoming.getJersey(), existing.getJersey()));
		existing.setMember(firstNonBlank(incoming.getMember(), existing.getMember()));
		existing.setFacePicPath(preferFace(incoming.getFacePicPath(), existing.getFacePicPath()));
		existing.setBelongList(mergeBelongList(existing.getBelongList(), existing.getTeam()));
		existing.setHeight(firstNonBlank(incoming.getHeight(), existing.getHeight()));
		existing.setWeight(firstNonBlank(incoming.getWeight(), existing.getWeight()));
		existing.setPosition(firstNonBlank(incoming.getPosition(), existing.getPosition()));
		existing.setBirth(firstNonBlank(incoming.getBirth(), existing.getBirth()));
		existing.setAge(firstNonBlank(incoming.getAge(), existing.getAge()));
		existing.setMarketValue(firstNonBlank(incoming.getMarketValue(), existing.getMarketValue()));
		existing.setInjury(mergeInjury(existing.getInjury(), incoming.getInjury()));
		existing.setVersusTeamScoreData(
				firstNonBlank(incoming.getVersusTeamScoreData(), existing.getVersusTeamScoreData()));
		existing.setDeadline(firstNonBlank(incoming.getDeadline(), existing.getDeadline()));
		existing.setDeadlineContractDate(
				firstNonBlank(incoming.getDeadlineContractDate(), existing.getDeadlineContractDate()));
		existing.setRetireFlg("0");
		existing.setLatestInfoDate(runDate);
		existing.setMissingCount("0");

		return existing;
	}

	/**
	 * 同一人物だが team が変わった場合の移籍更新
	 *
	 * ※ country が変わっていても same person なら更新扱い
	 */
	private TeamMemberMasterEntity applyTransfer(TeamMemberMasterEntity existing,
			TeamMemberMasterEntity incoming,
			String runDate) {

		existing.setBelongList(
				mergeBelongList(existing.getBelongList(), existing.getTeam(), incoming.getTeam()));

		existing.setCountry(firstNonBlank(incoming.getCountry(), existing.getCountry()));
		existing.setLeague(firstNonBlank(incoming.getLeague(), existing.getLeague()));
		existing.setTeam(firstNonBlank(incoming.getTeam(), existing.getTeam()));
		existing.setScore(mergeScore(existing.getScore(), incoming.getScore()));
		existing.setLoanBelong(mergeCsvDistinct(existing.getLoanBelong(), incoming.getLoanBelong()));
		existing.setJersey(firstNonBlank(incoming.getJersey(), existing.getJersey()));
		existing.setMember(firstNonBlank(incoming.getMember(), existing.getMember()));
		existing.setFacePicPath(preferFace(incoming.getFacePicPath(), existing.getFacePicPath()));
		existing.setHeight(firstNonBlank(incoming.getHeight(), existing.getHeight()));
		existing.setWeight(firstNonBlank(incoming.getWeight(), existing.getWeight()));
		existing.setPosition(firstNonBlank(incoming.getPosition(), existing.getPosition()));
		existing.setBirth(firstNonBlank(incoming.getBirth(), existing.getBirth()));
		existing.setAge(firstNonBlank(incoming.getAge(), existing.getAge()));
		existing.setMarketValue(firstNonBlank(incoming.getMarketValue(), existing.getMarketValue()));
		existing.setInjury(mergeInjury(existing.getInjury(), incoming.getInjury()));
		existing.setVersusTeamScoreData(
				firstNonBlank(incoming.getVersusTeamScoreData(), existing.getVersusTeamScoreData()));
		existing.setDeadline(firstNonBlank(incoming.getDeadline(), existing.getDeadline()));
		existing.setDeadlineContractDate(
				firstNonBlank(incoming.getDeadlineContractDate(), existing.getDeadlineContractDate()));
		existing.setRetireFlg("0");
		existing.setLatestInfoDate(runDate);
		existing.setMissingCount("0");

		return existing;
	}

	/**
	 * 引退扱いにする閾値に対応した引退フラグ設定
	 * @param existing
	 * @return
	 */
	private TeamMemberMasterEntity markMissingOrRetired(TeamMemberMasterEntity existing) {
		int current = parseIntSafe(existing.getMissingCount());
		int next = current + 1;
		existing.setMissingCount(String.valueOf(next));
		existing.setRetireFlg(next >= RETIRE_MISSING_THRESHOLD ? "1" : "0");
		return existing;
	}

	// =========================================================================
	// マージユーティリティ
	// =========================================================================

	private String mergeBelongList(String... values) {
		LinkedHashSet<String> set = new LinkedHashSet<>();
		for (String value : values) {
			if (isBlank(value)) {
				continue;
			}
			for (String token : value.split(",")) {
				String cleaned = clean(token);
				if (!isBlank(cleaned)) {
					set.add(cleaned);
				}
			}
		}
		return set.isEmpty() ? null : String.join(",", set);
	}

	private String mergeCsvDistinct(String a, String b) {
		return mergeBelongList(a, b);
	}

	private String mergeScore(String oldScore, String newScore) {
		if (isBlank(oldScore)) {
			return clean(newScore);
		}
		if (isBlank(newScore)) {
			return clean(oldScore);
		}
		if (eq(oldScore, newScore)) {
			return clean(oldScore);
		}
		return clean(newScore);
	}

	private String preferFace(String newFace, String oldFace) {
		return isBlank(newFace) ? clean(oldFace) : clean(newFace);
	}

	private String mergeInjury(String oldVal, String newVal) {
		if (isBlank(newVal) || "N/A".equalsIgnoreCase(newVal.trim())) {
			return clean(oldVal);
		}
		return clean(newVal);
	}

	// =========================================================================
	// Entity コピー
	// =========================================================================

	private TeamMemberMasterEntity copyOf(TeamMemberMasterEntity src) {
		TeamMemberMasterEntity e = new TeamMemberMasterEntity();
		e.setId(src.getId());
		e.setFile(src.getFile());
		e.setCountry(src.getCountry());
		e.setLeague(src.getLeague());
		e.setTeam(src.getTeam());
		e.setScore(src.getScore());
		e.setLoanBelong(src.getLoanBelong());
		e.setJersey(src.getJersey());
		e.setMember(src.getMember());
		e.setFacePicPath(src.getFacePicPath());
		e.setBelongList(src.getBelongList());
		e.setHeight(src.getHeight());
		e.setWeight(src.getWeight());
		e.setPosition(src.getPosition());
		e.setBirth(src.getBirth());
		e.setAge(src.getAge());
		e.setMarketValue(src.getMarketValue());
		e.setInjury(src.getInjury());
		e.setVersusTeamScoreData(src.getVersusTeamScoreData());
		e.setRetireFlg(src.getRetireFlg());
		e.setDeadline(src.getDeadline());
		e.setDeadlineContractDate(src.getDeadlineContractDate());
		e.setLatestInfoDate(src.getLatestInfoDate());
		e.setUpdStamp(src.getUpdStamp());
		e.setDelFlg(src.getDelFlg());
		e.setMissingCount(src.getMissingCount());
		return e;
	}

	// =========================================================================
	// 文字列ユーティリティ
	// =========================================================================

	private void normalizeEntity(TeamMemberMasterEntity e, String runDate) {
		if (e == null) {
			return;
		}

		e.setCountry(clean(e.getCountry()));
		e.setLeague(clean(e.getLeague()));
		e.setTeam(clean(e.getTeam()));
		e.setScore(clean(e.getScore()));
		e.setLoanBelong(cleanCsv(e.getLoanBelong()));
		e.setJersey(clean(e.getJersey()));
		e.setMember(clean(e.getMember()));
		e.setFacePicPath(clean(e.getFacePicPath()));
		e.setBelongList(cleanCsv(e.getBelongList()));
		e.setHeight(clean(e.getHeight()));
		e.setWeight(clean(e.getWeight()));
		e.setPosition(clean(e.getPosition()));
		e.setBirth(clean(e.getBirth()));
		e.setAge(clean(e.getAge()));
		e.setMarketValue(clean(e.getMarketValue()));
		e.setInjury(clean(e.getInjury()));
		e.setVersusTeamScoreData(clean(e.getVersusTeamScoreData()));
		e.setDeadline(clean(e.getDeadline()));
		e.setDeadlineContractDate(clean(e.getDeadlineContractDate()));

		if (isBlank(e.getRetireFlg())) {
			e.setRetireFlg("0");
		}
		if (isBlank(e.getMissingCount())) {
			e.setMissingCount("0");
		}
		if (isBlank(e.getLatestInfoDate())) {
			e.setLatestInfoDate(runDate);
		}
		if (isBlank(e.getDelFlg())) {
			e.setDelFlg("0");
		}
	}

	private String clean(String s) {
		if (s == null) {
			return null;
		}
		return s.replace('　', ' ').trim().replaceAll("\\s+", " ");
	}

	private String cleanCsv(String s) {
		if (isBlank(s)) {
			return null;
		}
		return Arrays.stream(s.split(","))
				.map(this::clean)
				.filter(x -> !isBlank(x))
				.distinct()
				.collect(Collectors.joining(","));
	}

	private boolean isBlank(String s) {
		return s == null || s.trim().isEmpty();
	}

	private boolean isBlank(Integer s) {
		return s == null;
	}

	private boolean eq(String a, String b) {
		return Objects.equals(clean(a), clean(b));
	}

	private String firstNonBlank(String... values) {
		for (String v : values) {
			if (!isBlank(v)) {
				return clean(v);
			}
		}
		return null;
	}

	private String nvl(String s) {
		return s == null ? "" : s;
	}

	private int parseIntSafe(String s) {
		if (isBlank(s)) {
			return 0;
		}
		try {
			return Integer.parseInt(s.trim());
		} catch (NumberFormatException e) {
			return 0;
		}
	}
}