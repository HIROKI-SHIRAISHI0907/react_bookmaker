package dev.batch.repository.bm;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import dev.batch.bm_b010.DataCategoryDTO;
import dev.batch.bm_b010.SeqKeyDTO;
import dev.batch.bm_b012.TeamPair;
import dev.common.entity.DataEntity;

/**
 * static_data の Repository（batch）
 *
 * <p>2026-10 追加（B010 の seq_key・data_category を「同じ試合」の範囲だけで決めるため）</p>
 * <ul>
 *   <li>findSeqKeyByMatchIdOrPrefix / findProvisionalSeqKeys / findLatestSeqKeyForCard（SeqKeyBatchService）</li>
 *   <li>findDataCategoryForMatch / updateDataCategoryForMatch（DataCategoryBatchService）</li>
 * </ul>
 * 「同じ試合」= 同じ match_id、または同じカード（NFKC 正規化）で record_time が基準時刻（baseTime。空なら現在時刻 JST）の前後 6 時間以内。
 *
 * <p>2026-10 修正（B012）</p>
 * <ul>
 *   <li>findMatchIdsWithoutFinishedCategoryByTeams: 「終了済」を times 列で判定・前日の範囲に絞る・match_id ごとに1件。</li>
 * </ul>
 *
 * <p>2026-10 追加2（B010 の data_category 修正）</p>
 * <ul>
 *   <li>findFinCountForMatch: 終了済の登録済みチェックを同じ試合（match_id）単位で行う。</li>
 *   <li>findMainCountryLeagueByTeam: チームの「国: リーグ」を static_data から求める（前後180日で試合数が一番多いもの）。</li>
 * </ul>
 */
@Mapper
public interface BookDataRepository {

	/**
	 * 対戦カード（home/away）単位でPostgreSQLのトランザクションスコープ・アドバイザリロックを取得する。
	 * SeqKeyBatchService#create() の先頭で呼び出し、同一対戦カードの採番を複数プロセス間で直列化する。
	 * ロックは呼び出し元のトランザクションがCOMMIT/ROLLBACKされた時点で自動的に解放される。
	 * 戻り値は常に false（呼び出し側で使う必要はない）。
	 */
	@Select("""
			SELECT pg_advisory_xact_lock(
			    hashtext(
			        normalize(#{homeTeamName}, NFKC) || '|' || normalize(#{awayTeamName}, NFKC)
			    )::bigint
			) IS NULL
			""")
	Boolean lockByTeams(@Param("homeTeamName") String homeTeamName,
			@Param("awayTeamName") String awayTeamName);

	@Insert("""
			INSERT INTO static_data (
			    seq_key,
			    condition_result_data_seq_id,
			    data_category,
			    times,
			    home_rank,
			    home_team_name,
			    home_score,
			    away_rank,
			    away_team_name,
			    away_score,
			    home_exp,
			    away_exp,
			    home_in_goal_exp,
			    away_in_goal_exp,
			    home_donation,
			    away_donation,
			    home_shoot_all,
			    away_shoot_all,
			    home_shoot_in,
			    away_shoot_in,
			    home_shoot_out,
			    away_shoot_out,
			    home_block_shoot,
			    away_block_shoot,
			    home_big_chance,
			    away_big_chance,
			    home_corner,
			    away_corner,
			    home_box_shoot_in,
			    away_box_shoot_in,
			    home_box_shoot_out,
			    away_box_shoot_out,
			    home_goal_post,
			    away_goal_post,
			    home_goal_head,
			    away_goal_head,
			    home_keeper_save,
			    away_keeper_save,
			    home_free_kick,
			    away_free_kick,
			    home_offside,
			    away_offside,
			    home_foul,
			    away_foul,
			    home_yellow_card,
			    away_yellow_card,
			    home_red_card,
			    away_red_card,
			    home_slow_in,
			    away_slow_in,
			    home_box_touch,
			    away_box_touch,
			    home_pass_count,
			    away_pass_count,
			    home_long_pass_count,
			    away_long_pass_count,
			    home_final_third_pass_count,
			    away_final_third_pass_count,
			    home_cross_count,
			    away_cross_count,
			    home_tackle_count,
			    away_tackle_count,
			    home_clear_count,
			    away_clear_count,
			    home_duel_count,
			    away_duel_count,
			    home_intercept_count,
			    away_intercept_count,
			    record_time,
			    weather,
			    temparature,
			    humid,
			    judge_member,
			    home_manager,
			    away_manager,
			    home_formation,
			    away_formation,
			    studium,
			    capacity,
			    audience,
			    location,
			    home_max_getting_scorer,
			    away_max_getting_scorer,
			    home_max_getting_scorer_game_situation,
			    away_max_getting_scorer_game_situation,
			    home_team_home_score,
			    home_team_home_lost,
			    away_team_home_score,
			    away_team_home_lost,
			    home_team_away_score,
			    home_team_away_lost,
			    away_team_away_score,
			    away_team_away_lost,
			    notice_flg,
			    game_link,
			    goal_time,
			    goal_team_member,
			    judge,
			    home_team_style,
			    away_team_style,
			    probablity,
			    prediction_score_time,
			    game_id,
			    match_id,
			    time_sort_seconds,
			    add_manual_flg,
			    register_id,
			    register_time,
			    update_id,
			    update_time
			) VALUES (
			    #{seqKey},
			    #{conditionResultDataSeqId},
			    #{dataCategory},
			    #{times},
			    #{homeRank},
			    #{homeTeamName},
			    #{homeScore},
			    #{awayRank},
			    #{awayTeamName},
			    #{awayScore},
			    #{homeExp},
			    #{awayExp},
			    #{homeInGoalExp},
			    #{awayInGoalExp},
			    #{homeDonation},
			    #{awayDonation},
			    #{homeShootAll},
			    #{awayShootAll},
			    #{homeShootIn},
			    #{awayShootIn},
			    #{homeShootOut},
			    #{awayShootOut},
			    #{homeBlockShoot},
			    #{awayBlockShoot},
			    #{homeBigChance},
			    #{awayBigChance},
			    #{homeCorner},
			    #{awayCorner},
			    #{homeBoxShootIn},
			    #{awayBoxShootIn},
			    #{homeBoxShootOut},
			    #{awayBoxShootOut},
			    #{homeGoalPost},
			    #{awayGoalPost},
			    #{homeGoalHead},
			    #{awayGoalHead},
			    #{homeKeeperSave},
			    #{awayKeeperSave},
			    #{homeFreeKick},
			    #{awayFreeKick},
			    #{homeOffside},
			    #{awayOffside},
			    #{homeFoul},
			    #{awayFoul},
			    #{homeYellowCard},
			    #{awayYellowCard},
			    #{homeRedCard},
			    #{awayRedCard},
			    #{homeSlowIn},
			    #{awaySlowIn},
			    #{homeBoxTouch},
			    #{awayBoxTouch},
			    #{homePassCount},
			    #{awayPassCount},
			    #{homeLongPassCount},
			    #{awayLongPassCount},
			    #{homeFinalThirdPassCount},
			    #{awayFinalThirdPassCount},
			    #{homeCrossCount},
			    #{awayCrossCount},
			    #{homeTackleCount},
			    #{awayTackleCount},
			    #{homeClearCount},
			    #{awayClearCount},
			    #{homeDuelCount},
			    #{awayDuelCount},
			    #{homeInterceptCount},
			    #{awayInterceptCount},
			    CAST(NULLIF(#{recordTime}, '') AS timestamp),
			    #{weather},
			    #{temparature},
			    #{humid},
			    #{judgeMember},
			    #{homeManager},
			    #{awayManager},
			    #{homeFormation},
			    #{awayFormation},
			    #{studium},
			    #{capacity},
			    #{audience},
			    #{location},
			    #{homeMaxGettingScorer},
			    #{awayMaxGettingScorer},
			    #{homeMaxGettingScorerGameSituation},
			    #{awayMaxGettingScorerGameSituation},
			    #{homeTeamHomeScore},
			    #{homeTeamHomeLost},
			    #{awayTeamHomeScore},
			    #{awayTeamHomeLost},
			    #{homeTeamAwayScore},
			    #{homeTeamAwayLost},
			    #{awayTeamAwayScore},
			    #{awayTeamAwayLost},
			    #{noticeFlg},
			    #{gameLink},
			    #{goalTime},
			    #{goalTeamMember},
			    #{judge},
			    #{homeTeamStyle},
			    #{awayTeamStyle},
			    #{probablity},
			    #{predictionScoreTime},
			    #{gameId},
			    #{matchId},
			    #{timeSortSeconds},
			    #{addManualFlg},
			    'SYSTEM',
			    CURRENT_TIMESTAMP,
			    'SYSTEM',
			    CURRENT_TIMESTAMP
			)
			""")
	int insert(DataEntity entity);

	@Select("""
			SELECT COUNT(*)
			FROM static_data
			WHERE data_category = #{dataCategory}
			  AND times = #{times}
			  AND normalize(home_team_name, NFKC) = normalize(#{homeTeamName}, NFKC)
			  AND normalize(away_team_name, NFKC) = normalize(#{awayTeamName}, NFKC)
			  AND match_id        = #{matchId}
			""")
	int findDataCount(DataEntity entity);

	/**
	 * 同じカードの終了済の件数（全期間）。
	 * ※ 翌シーズン以降の同じカードも数えてしまうため B010 では使わない（{@link #findFinCountForMatch} を使う）。
	 */
	@Select("""
			SELECT COUNT(*)
			FROM static_data
			WHERE data_category IS NOT NULL
			  AND times = #{times}
			  AND normalize(home_team_name, NFKC) = normalize(#{homeTeamName}, NFKC)
			  AND normalize(away_team_name, NFKC) = normalize(#{awayTeamName}, NFKC);
			""")
	int findFinCount(DataEntity entity);

	@Delete("""
			DELETE
			FROM static_data
			WHERE data_category LIKE CONCAT(#{dataCategoryLike}, '%')
			""")
	int deleteByDataCategory(@Param("dataCategoryLike") String categoryLike);

	@Select("""
			SELECT COUNT(*)
			FROM static_data
			""")
	int findChk();

	@Select("""
			SELECT COUNT(*)
			FROM (
			    SELECT DISTINCT data_category, home_team_name, location, studium
			    FROM static_data
			    WHERE data_category IS NOT NULL
			  		AND data_category <> ''
			  		AND home_team_name IS NOT NULL
			  		AND home_team_name <> ''
			  		AND studium IS NOT NULL
			  		AND studium <> ''
			) t
			""")
	int countStadium();

	@Select("""
			SELECT DISTINCT
				   data_category AS dataCategory,
			       home_team_name AS homeTeamName,
			       location,
			       studium
			FROM static_data
			WHERE data_category IS NOT NULL
			  AND data_category <> ''
			  AND home_team_name IS NOT NULL
			  AND home_team_name <> ''
			  AND studium IS NOT NULL
			  AND studium <> ''
			ORDER BY home_team_name, studium, data_category, location
			LIMIT #{limit} OFFSET #{offset}
			""")
	List<DataEntity> findStadium(@Param("limit") int limit, @Param("offset") int offset);

	@Select("""
			SELECT
			    seq_key AS seqKey,
				match_id AS matchId,
				times
			FROM static_data
				WHERE normalize(home_team_name, NFKC) = normalize(#{homeTeamName}, NFKC)
				AND normalize(away_team_name, NFKC) = normalize(#{awayTeamName}, NFKC)
			ORDER BY
				(regexp_match(seq_key, '-(\\d+)$'))[1]::integer DESC,
				register_time DESC;
			""")
	List<SeqKeyDTO> findMatchId(
			@Param("homeTeamName") String homeTeamName,
			@Param("awayTeamName") String awayTeamName);

	@Select("""
			SELECT
			    seq_key AS seqKey,
				match_id AS matchId
			FROM static_data
				WHERE match_id = #{matchId}
			ORDER BY seq_key DESC
			LIMIT 1;
			""")
	SeqKeyDTO findSeqKeyByMatchId(
			@Param("matchId") String matchId);

	@Select("""
			SELECT COUNT(*)
			FROM static_data
			WHERE seq_key LIKE CONCAT(#{prefix}, '-%')
			""")
	int existsSeqKeyPrefix(@Param("prefix") String prefix);

	@Update("""
			UPDATE static_data
			SET seq_key = #{newSeqKey},
			    match_id = #{matchId}
			WHERE seq_key = #{oldSeqKey}
			""")
	int updateSeqKey(@Param("oldSeqKey") String oldSeqKey,
			@Param("newSeqKey") String newSeqKey,
			@Param("matchId") String matchId);

	@Select("""
			SELECT
				data_category AS dataCategory,
				times
			FROM static_data
				WHERE normalize(home_team_name, NFKC) = normalize(#{homeTeamName}, NFKC)
				AND normalize(away_team_name, NFKC) = normalize(#{awayTeamName}, NFKC)
			ORDER BY register_time DESC;
			""")
	List<DataCategoryDTO> findDataCategory(
			@Param("homeTeamName") String homeTeamName,
			@Param("awayTeamName") String awayTeamName);

	@Update("""
			UPDATE static_data
			SET data_category = #{dataCategory}
				WHERE normalize(home_team_name, NFKC) = normalize(#{homeTeamName}, NFKC)
				AND normalize(away_team_name, NFKC) = normalize(#{awayTeamName}, NFKC);
			""")
	int updateByDataCategory(
			@Param("dataCategory") String dataCategory,
			@Param("homeTeamName") String homeTeamName,
			@Param("awayTeamName") String awayTeamName);

	/**
	 * B012: 前日に記録があり、「終了済」の行が無い試合（match_id ごとに1件）。
	 * <ul>
	 *   <li>「終了済」は times 列（試合時間）で判定する。data_category には「国: リーグ - ラウンド N」が入っている。</li>
	 *   <li>record_time（timestamp・日本時間）が前日の範囲。日付をまたぐ試合のため終わりは +6 時間。</li>
	 *   <li>終了済の判定は日付で絞らず、同じ match_id の全ての行で見る。</li>
	 *   <li>recordTime はその試合の最初の record_time（オフセット無しの日本時間 "yyyy-MM-dd HH:mm:ss"）。</li>
	 * </ul>
	 * @param dayStart 前日 0:00（日本時間）の UTC ISO 文字列（例: 2026-10-10T15:00:00Z）
	 * @param dayEnd   前日の終わり（日本時間）の UTC ISO 文字列
	 */
	@Select("""
			<script>
			SELECT
			  d.match_id                                        AS matchId,
			  to_char(MIN(d.record_time), 'YYYY-MM-DD HH24:MI:SS') AS recordTime,
			  MIN(d.home_team_name)                             AS homeTeamName,
			  MIN(d.away_team_name)                             AS awayTeamName
			FROM static_data d
			WHERE NULLIF(BTRIM(d.match_id), '') IS NOT NULL
			  AND d.record_time &gt;= (CAST(#{dayStart} AS timestamptz) AT TIME ZONE 'Asia/Tokyo')
			  AND d.record_time &lt;  (CAST(#{dayEnd} AS timestamptz) AT TIME ZONE 'Asia/Tokyo') + INTERVAL '6 hours'
			  AND BTRIM(COALESCE(d.home_team_name, '')) &lt;&gt; ''
			  AND BTRIM(COALESCE(d.away_team_name, '')) &lt;&gt; ''
			  <if test="teamPairs != null and teamPairs.size() > 0">
			  AND (normalize(d.home_team_name, NFKC), normalize(d.away_team_name, NFKC)) IN (
			    VALUES
			    <foreach collection="teamPairs" item="pair" separator=",">
			      (normalize(#{pair.homeTeamName}, NFKC), normalize(#{pair.awayTeamName}, NFKC))
			    </foreach>
			  )
			  </if>
			  AND NOT EXISTS (
			        SELECT 1
			        FROM static_data d2
			        WHERE d2.match_id = d.match_id
			          AND REPLACE(BTRIM(normalize(COALESCE(d2.times, ''), NFKC)), ' ', '') = '終了済'
			  )
			GROUP BY d.match_id
			ORDER BY MIN(d.record_time)
			</script>
			""")
	List<SeqKeyDTO> findMatchIdsWithoutFinishedCategoryByTeams(
			@Param("teamPairs") List<TeamPair> teamPairs,
			@Param("dayStart") String dayStart,
			@Param("dayEnd") String dayEnd);

	@Select("""
				SELECT
					data_category
				FROM
					static_data
				WHERE
					(
						normalize(home_team_name, NFKC) = normalize(#{team}, NFKC)
					OR
						normalize(away_team_name, NFKC) = normalize(#{team}, NFKC)
					)
					AND
					data_category IS NOT NULL
				LIMIT 1
			""")
	String findDataCategoryByTeams(
			@Param("team") String team);

	@Update("""
	        UPDATE static_data
	        SET data_category = #{dataCategory}
	        WHERE normalize(home_team_name, NFKC) = normalize(#{homeTeamName}, NFKC)
	          AND normalize(away_team_name, NFKC) = normalize(#{awayTeamName}, NFKC)
	          AND (data_category IS NULL OR data_category NOT LIKE '%ラウンド%')
	        """)
	int updateByDataCategoryWithNotRound(
	        @Param("dataCategory") String dataCategory,
	        @Param("homeTeamName") String homeTeamName,
	        @Param("awayTeamName") String awayTeamName);

	/**
	 * seq_key 振り直し対象を取得する。
	 * 対象: 同一対戦カード(home/away)の行 ＋ すでに matchId- で始まる seq_key の行
	 * ※ 全期間の同じカードが対象のため B010 では使わない（findProvisionalSeqKeys を使う）
	 */
	@Select("""
			SELECT
			    seq_key AS seqKey,
			    match_id AS matchId,
			    times
			FROM static_data
			WHERE (
			        normalize(home_team_name, NFKC) = normalize(#{homeTeamName}, NFKC)
			    AND normalize(away_team_name, NFKC) = normalize(#{awayTeamName}, NFKC)
			      )
			   OR seq_key LIKE CONCAT(#{matchId}, '-%')
			ORDER BY
			    register_time ASC,
			    (regexp_match(seq_key, '-(\\d+)$'))[1]::integer ASC,
			    seq_key ASC
			""")
	List<SeqKeyDTO> findSeqKeysForRenumber(
			@Param("homeTeamName") String homeTeamName,
			@Param("awayTeamName") String awayTeamName,
			@Param("matchId") String matchId);

	/**
	 * seq_key を一時キー（tempPrefix + 元のseq_key）に退避する。
	 */
	@Update("""
			<script>
			UPDATE static_data
			SET seq_key = CONCAT(#{tempPrefix}, seq_key)
			WHERE seq_key IN
			  <foreach collection='seqKeys' item='k' open='(' separator=',' close=')'>
			    #{k}
			  </foreach>
			</script>
			""")
	int moveSeqKeysToTemp(
			@Param("tempPrefix") String tempPrefix,
			@Param("seqKeys") List<String> seqKeys);

	// ===================== 2026-10 追加 =====================

	/**
	 * この match_id の最大の連番の行（match_id が一致する行、または seq_key が "matchId-N" の行）。無ければ null。
	 */
	@Select("""
			SELECT
			    seq_key AS seqKey,
			    match_id AS matchId
			FROM static_data
			WHERE match_id = #{matchId}
			   OR seq_key LIKE CONCAT(#{matchId}, '-%')
			ORDER BY NULLIF(SUBSTRING(seq_key FROM '-([0-9]+)$'), '')::BIGINT DESC NULLS LAST
			LIMIT 1
			""")
	SeqKeyDTO findSeqKeyByMatchIdOrPrefix(
			@Param("matchId") String matchId);

	/**
	 * 同じ試合で match_id がまだ無い（乱数で採番した）行。振り直しの対象。
	 */
	@Select("""
			SELECT
			    seq_key AS seqKey,
			    match_id AS matchId,
			    times
			FROM static_data
			WHERE normalize(home_team_name, NFKC) = normalize(#{homeTeamName}, NFKC)
			  AND normalize(away_team_name, NFKC) = normalize(#{awayTeamName}, NFKC)
			  AND BTRIM(home_team_name) <> ''
			  AND BTRIM(away_team_name) <> ''
			  AND NULLIF(BTRIM(match_id), '') IS NULL
			  AND seq_key NOT LIKE '~%'
			  AND record_time BETWEEN COALESCE(CAST(NULLIF(BTRIM(#{baseTime,jdbcType=VARCHAR}), '') AS timestamp), CAST(now() AT TIME ZONE 'Asia/Tokyo' AS timestamp)) - INTERVAL '6 hours' AND COALESCE(CAST(NULLIF(BTRIM(#{baseTime,jdbcType=VARCHAR}), '') AS timestamp), CAST(now() AT TIME ZONE 'Asia/Tokyo' AS timestamp)) + INTERVAL '6 hours'
			ORDER BY
			    register_time ASC,
			    NULLIF(SUBSTRING(seq_key FROM '-([0-9]+)$'), '')::BIGINT ASC NULLS LAST,
			    seq_key ASC
			""")
	List<SeqKeyDTO> findProvisionalSeqKeys(
			@Param("homeTeamName") String homeTeamName,
			@Param("awayTeamName") String awayTeamName,
			@Param("baseTime") String baseTime);

	/**
	 * 同じ試合（同じカード・record_time が基準時刻の前後 6 時間以内）の最新の行。無ければ null。
	 */
	@Select("""
			SELECT
			    seq_key AS seqKey,
			    match_id AS matchId,
			    times
			FROM static_data
			WHERE normalize(home_team_name, NFKC) = normalize(#{homeTeamName}, NFKC)
			  AND normalize(away_team_name, NFKC) = normalize(#{awayTeamName}, NFKC)
			  AND BTRIM(home_team_name) <> ''
			  AND BTRIM(away_team_name) <> ''
			  AND seq_key NOT LIKE '~%'
			  AND record_time BETWEEN COALESCE(CAST(NULLIF(BTRIM(#{baseTime,jdbcType=VARCHAR}), '') AS timestamp), CAST(now() AT TIME ZONE 'Asia/Tokyo' AS timestamp)) - INTERVAL '6 hours' AND COALESCE(CAST(NULLIF(BTRIM(#{baseTime,jdbcType=VARCHAR}), '') AS timestamp), CAST(now() AT TIME ZONE 'Asia/Tokyo' AS timestamp)) + INTERVAL '6 hours'
			ORDER BY
			    register_time DESC,
			    NULLIF(SUBSTRING(seq_key FROM '-([0-9]+)$'), '')::BIGINT DESC NULLS LAST
			LIMIT 1
			""")
	SeqKeyDTO findLatestSeqKeyForCard(
			@Param("homeTeamName") String homeTeamName,
			@Param("awayTeamName") String awayTeamName,
			@Param("baseTime") String baseTime);

	/**
	 * 同じ試合（同じ match_id、または同じカードで record_time が基準時刻の前後 6 時間以内）の data_category。新しい順。
	 * 仮の値「XXX: YYY …」は除く。
	 */
	@Select("""
			SELECT
				data_category AS dataCategory,
				times
			FROM static_data
			WHERE normalize(home_team_name, NFKC) = normalize(#{homeTeamName}, NFKC)
			  AND normalize(away_team_name, NFKC) = normalize(#{awayTeamName}, NFKC)
			  AND (match_id = #{matchId,jdbcType=VARCHAR}
			       OR record_time BETWEEN COALESCE(CAST(NULLIF(BTRIM(#{baseTime,jdbcType=VARCHAR}), '') AS timestamp), CAST(now() AT TIME ZONE 'Asia/Tokyo' AS timestamp)) - INTERVAL '6 hours' AND COALESCE(CAST(NULLIF(BTRIM(#{baseTime,jdbcType=VARCHAR}), '') AS timestamp), CAST(now() AT TIME ZONE 'Asia/Tokyo' AS timestamp)) + INTERVAL '6 hours')
			  AND data_category IS NOT NULL
			  AND data_category !~* '^\\s*XXX\\s*:'
			ORDER BY register_time DESC
			""")
	List<DataCategoryDTO> findDataCategoryForMatch(
			@Param("homeTeamName") String homeTeamName,
			@Param("awayTeamName") String awayTeamName,
			@Param("matchId") String matchId,
			@Param("baseTime") String baseTime);

	/**
	 * 同じ試合（同じ match_id、または同じカードで record_time が基準時刻の前後 6 時間以内）の data_category を更新する。
	 */
	@Update("""
			UPDATE static_data
			SET data_category = #{dataCategory}
			WHERE normalize(home_team_name, NFKC) = normalize(#{homeTeamName}, NFKC)
			  AND normalize(away_team_name, NFKC) = normalize(#{awayTeamName}, NFKC)
			  AND (match_id = #{matchId,jdbcType=VARCHAR}
			       OR record_time BETWEEN COALESCE(CAST(NULLIF(BTRIM(#{baseTime,jdbcType=VARCHAR}), '') AS timestamp), CAST(now() AT TIME ZONE 'Asia/Tokyo' AS timestamp)) - INTERVAL '6 hours' AND COALESCE(CAST(NULLIF(BTRIM(#{baseTime,jdbcType=VARCHAR}), '') AS timestamp), CAST(now() AT TIME ZONE 'Asia/Tokyo' AS timestamp)) + INTERVAL '6 hours')
			  AND data_category IS DISTINCT FROM #{dataCategory}
			""")
	int updateDataCategoryForMatch(
			@Param("dataCategory") String dataCategory,
			@Param("homeTeamName") String homeTeamName,
			@Param("awayTeamName") String awayTeamName,
			@Param("matchId") String matchId,
			@Param("baseTime") String baseTime);

	// ===================== 2026-10 追加2 =====================

	/**
	 * 同じ試合の終了済の件数。
	 * <ul>
	 *   <li>match_id があれば同じ match_id の行だけを数える。</li>
	 *   <li>match_id が無ければ同じカード（NFKC）で record_time が記録時刻の前後 1 日以内の行を数える。</li>
	 * </ul>
	 */
	@Select("""
			SELECT COUNT(*)
			FROM static_data
			WHERE times = #{times}
			  AND data_category IS NOT NULL
			  AND (
			        (NULLIF(BTRIM(#{matchId,jdbcType=VARCHAR}), '') IS NOT NULL
			         AND match_id = #{matchId,jdbcType=VARCHAR})
			     OR (NULLIF(BTRIM(#{matchId,jdbcType=VARCHAR}), '') IS NULL
			         AND normalize(home_team_name, NFKC) = normalize(#{homeTeamName}, NFKC)
			         AND normalize(away_team_name, NFKC) = normalize(#{awayTeamName}, NFKC)
			         AND record_time BETWEEN COALESCE(CAST(NULLIF(BTRIM(#{recordTime,jdbcType=VARCHAR}), '') AS timestamp), CAST(now() AT TIME ZONE 'Asia/Tokyo' AS timestamp)) - INTERVAL '1 day' AND COALESCE(CAST(NULLIF(BTRIM(#{recordTime,jdbcType=VARCHAR}), '') AS timestamp), CAST(now() AT TIME ZONE 'Asia/Tokyo' AS timestamp)) + INTERVAL '1 day')
			  )
			""")
	int findFinCountForMatch(DataEntity entity);

	/**
	 * チームの「国: リーグ」を static_data から求める。
	 * <ul>
	 *   <li>ホームまたはアウェーがそのチーム（NFKC）で、data_category が「国: リーグ …」の形（XXX は除く）。</li>
	 *   <li>record_time が基準時刻の前後 180 日（昇格・降格前のシーズンを混ぜにくくする）。</li>
	 *   <li>「 - 」より前を「国: リーグ」とし、試合数（match_id、無ければ seq_key）が一番多いもの
	 *       （カップ戦より通常リーグが優先される）。同数なら新しいもの。</li>
	 * </ul>
	 * 無ければ null。
	 */
	@Select("""
			SELECT BTRIM(split_part(data_category, ' - ', 1)) AS base
			FROM static_data
			WHERE (normalize(home_team_name, NFKC) = normalize(#{team}, NFKC)
			    OR normalize(away_team_name, NFKC) = normalize(#{team}, NFKC))
			  AND data_category ~ '^\\s*[^:：]+[:：]\\s*\\S'
			  AND data_category !~* '^\\s*XXX\\s*:'
			  AND record_time BETWEEN COALESCE(CAST(NULLIF(BTRIM(#{baseTime,jdbcType=VARCHAR}), '') AS timestamp), CAST(now() AT TIME ZONE 'Asia/Tokyo' AS timestamp)) - INTERVAL '180 days' AND COALESCE(CAST(NULLIF(BTRIM(#{baseTime,jdbcType=VARCHAR}), '') AS timestamp), CAST(now() AT TIME ZONE 'Asia/Tokyo' AS timestamp)) + INTERVAL '180 days'
			GROUP BY 1
			ORDER BY COUNT(DISTINCT COALESCE(NULLIF(BTRIM(match_id), ''), seq_key)) DESC,
			         MAX(record_time) DESC
			LIMIT 1
			""")
	String findMainCountryLeagueByTeam(
			@Param("team") String team,
			@Param("baseTime") String baseTime);

}