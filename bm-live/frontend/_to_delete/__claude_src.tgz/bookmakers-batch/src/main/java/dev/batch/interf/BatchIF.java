package dev.batch.interf;

/**
 * バッチInterface
 * @author shiraishitoshio
 *
 */
public interface BatchIF {

	/**
	 * バッチ実行
	 * @return
	 */
	public int execute(boolean readyFlg) throws Exception;

}
