package dev.batch.bm_b010;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import dev.batch.repository.bm.BookDataRepository;
import dev.common.constant.MessageCdConst;
import dev.common.entity.DataEntity;
import dev.common.logger.ManageLoggerComponent;

/**
 * DataDBService管理部品(「終了済」データとして追加登録用)
 *
 * <p>2026-10 修正: 登録済みチェックを同じ試合（match_id）単位に変更（findFinCountForMatch）。</p>
 * @author shiraishitoshio
 *
 */
@Component
@Transactional
public class DataDBService {

	/** プロジェクト名 */
	private static final String PROJECT_NAME = DataDBService.class.getProtectionDomain()
			.getCodeSource().getLocation().getPath();

	/** クラス名 */
	private static final String CLASS_NAME = DataDBService.class.getName();

	/** BookDataRepositoryレポジトリクラス */
	@Autowired
	private BookDataRepository bookDataRepository;

	/** static_dataへのINSERTをSAVEPOINT付きネストトランザクションで実行するヘルパー */
	@Autowired
	private StaticDataInsertExecutor staticDataInsertExecutor;

	/** ログ管理クラス */
	@Autowired
	private ManageLoggerComponent manageLoggerComponent;

	/**
	 * チェックメソッド（同じ試合の終了済が未登録なら対象を返す）
	 * @param chkEntities
	 */
	public DataEntity selectInBatch(DataEntity chkEntities) {
		int chk = bookDataRepository.findFinCountForMatch(chkEntities);
		return (chk == 0) ? chkEntities : null;
	}

	/**
	 * 登録メソッド
	 * @param insertEntities
	 */
	@Transactional(transactionManager = "bmTxManager", rollbackFor = Exception.class)
	public void insertInBatchOrThrow(DataEntity insertEntities) throws Exception {
		final String METHOD_NAME = "insertInBatchOrThrow";

		if (insertEntities == null)
			return;

		try {
			// staticDataInsertExecutor.insert() はPropagation.NESTEDで実行される。
			// DuplicateKeyExceptionをcatchする時点では既にSAVEPOINTまでロールバック済みなので、
			// 外側のトランザクション（finGettingStat側）は正常な状態のまま処理を継続できる。
			int result = staticDataInsertExecutor.insert(insertEntities);
			if (result != 1) {
				throw new Exception("bm insert failed. result=" + result);
			}
			String messageCd = MessageCdConst.MCD00005I_INSERT_SUCCESS;
			this.manageLoggerComponent.debugInfoLog(
					PROJECT_NAME, CLASS_NAME, METHOD_NAME, messageCd,
					"登録件数: " + result + "件 (" + insertEntities.getHomeTeamName() + " vs "
					+ insertEntities.getAwayTeamName() + ")");
		} catch (DuplicateKeyException e) {
			String messageCd = MessageCdConst.MCD00002W_DUPLICATION_WARNING;
			manageLoggerComponent.debugWarnLog(PROJECT_NAME, CLASS_NAME, METHOD_NAME, messageCd,
					"(" + insertEntities.getHomeTeamName() + " vs "
							+ insertEntities.getAwayTeamName()
							+ ", seqKey=" + insertEntities.getSeqKey()
							+ ", matchId=" + insertEntities.getMatchId()
							+ ", times=" + insertEntities.getTimes()
							+ ", dataCategory=" + insertEntities.getDataCategory()
							+ ", cause=" + rootCauseMessage(e)
							+ ")");
		}
	}

	/**
	 * DuplicateKeyExceptionの根本原因のメッセージを取り出す。
	 */
	private static String rootCauseMessage(Throwable e) {
		Throwable cur = e;
		while (cur.getCause() != null && cur.getCause() != cur) {
			cur = cur.getCause();
		}
		return cur.getMessage();
	}
}