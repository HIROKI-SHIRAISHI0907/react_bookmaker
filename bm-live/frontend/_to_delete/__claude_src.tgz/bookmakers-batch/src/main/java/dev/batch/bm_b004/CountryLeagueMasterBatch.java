package dev.batch.bm_b004;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dev.batch.common.AbstractJobBatchTemplate;
import dev.common.constant.MessageCdConst;
import dev.common.entity.CountryLeagueMasterEntity;
import dev.common.getinfo.GetTeamInfo;

/**
 * マスタ登録バッチ実行クラス。
 * <p>
 * 国・リーグなどのマスタデータを取得し、登録ロジック（Transactional想定）を実行する。
 * </p>
 *
 * <p><b>実行方式</b></p>
 * <ul>
 *   <li>開始/終了ログを必ず出力する</li>
 *   <li>例外は内部で捕捉し、debugErrorLog に例外を付与して出力する</li>
 *   <li>戻り値で成功/失敗を返却する</li>
 * </ul>
 *
 * <p>2026-10 修正（ヘッダしかない CSV が S3 に残り続ける問題）</p>
 * <ul>
 *   <li>GetTeamInfo はヘッダのみのファイルを「キー → 空のリスト」で返す。
 *       そのファイルは登録（国・リーグ／カラー）をせず、ファイルの削除だけ行う。</li>
 * </ul>
 *
 * @author shiraishitoshio
 */
@Service("B004")
public class CountryLeagueMasterBatch extends AbstractJobBatchTemplate {

	/** プロジェクト名 */
	private static final String PROJECT_NAME = CountryLeagueMasterBatch.class.getProtectionDomain()
			.getCodeSource().getLocation().getPath();

	/** クラス名 */
	private static final String CLASS_NAME = CountryLeagueMasterBatch.class.getName();

	/** エラーコード（運用ルールに合わせて変更） */
	private static final String ERROR_CODE = "BM_B004_ERROR";

	/** バッチコード */
	private static final String BATCH_CODE = "B004";

	/** オーバーライド */
	@Override
	protected String batchCode() {
		return BATCH_CODE;
	}

	@Override
	protected String errorCode() {
		return ERROR_CODE;
	}

	@Override
	protected String projectName() {
		return PROJECT_NAME;
	}

	@Override
	protected String className() {
		return CLASS_NAME;
	}

	/** マスタ情報取得管理クラス */
	@Autowired
	private GetTeamInfo getTeamMasterInfo;

	/** BM_M032統計分析ロジック */
	@Autowired
	private CountryLeagueMasterStat countryLeagueMasterStat;

	/** BM_M032統計分析ロジック */
	@Autowired
	private ColorMasterStat colorMasterStat;

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void doExecute(JobContext ctx) throws Exception {
		final String METHOD_NAME = "doExecute";
		// マスタデータ情報を取得
		Map<String, List<CountryLeagueMasterEntity>> listMap = this.getTeamMasterInfo.getData();
		if (listMap == null || listMap.isEmpty()) {
			endLog();
			return;
		}

		// 登録(Transactional)
		for (Map.Entry<String, List<CountryLeagueMasterEntity>> entry : listMap.entrySet()) {
			try {
				List<CountryLeagueMasterEntity> list = entry.getValue();
				if (list == null || list.isEmpty()) {
					// ヘッダのみ: 登録はせず、ファイルの削除だけ行う（残すと毎回同じファイルを読み続ける）
					this.manageLoggerComponent.debugInfoLog(
							PROJECT_NAME, CLASS_NAME, METHOD_NAME, MessageCdConst.MCD00099I_LOG,
							"登録対象が0件（ヘッダのみ）のため、ファイルの削除のみ行います: " + entry.getKey());
					this.countryLeagueMasterStat.deleteProcessedFile(entry.getKey());
					continue;
				}
				this.countryLeagueMasterStat.masterStat(entry.getKey(), list);
				this.colorMasterStat.masterStat(entry.getKey(), list);
			} catch (Exception e) {
				this.manageLoggerComponent.debugErrorLog(
						PROJECT_NAME, CLASS_NAME, METHOD_NAME, ERROR_CODE, e);
				continue;
			}
		}

		endLog();
	}

	/**
	 * 終了ログ
	 */
	private void endLog() {
		final String METHOD_NAME = "endLog";
		this.manageLoggerComponent.debugEndInfoLog(
				PROJECT_NAME, CLASS_NAME, METHOD_NAME);
	}
}