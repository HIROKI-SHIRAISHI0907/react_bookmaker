package dev.web.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import dev.web.api.bm_w013.StatRequestResource;
import dev.web.api.bm_w013.StatResponseResource;
import dev.web.batch.EcsBatchTaskRunner;
import lombok.RequiredArgsConstructor;

/**
 * FileUploadStatusExecution（ファイルアップロード反映）タスク実行用
 * <p>
 * CSV アップロード画面で受け付けた判定前（PENDING）のファイルを DB チェック・反映し、
 * S3 の success/ ・ error/ に振り分ける bookmakers-batch の B016 を起動する。
 * </p>
 * <p>
 * バッチコードは B016（B015 は地理情報スクレイパー ecs.scraper.B015 が使っているため）。
 * ecs.job に B016 の定義が無いときは ecs.defaults（bookmakers-batch）で起動する。
 * </p>
 * @author shiraishitoshio
 *
 */
@RestController
@RequestMapping("/api/admin/exec/task")
@RequiredArgsConstructor
public class AdminFileUploadStatusExecutionExecTaskController {

	/** バッチコード */
	private static final String BATCH_CODE = "B016";

	private final EcsBatchTaskRunner runner;

	/**
	 * /file-upload-status を叩いたら B016 の Fargate タスクを起動する
	 * <p>本文は使わない（無くてもよい。画面は他のタスクと同じく country 等を送ってくる）。</p>
	 */
	@PostMapping("/file-upload-status")
	public ResponseEntity<StatResponseResource> execute(@RequestBody(required = false) StatRequestResource req) {

		// 渡す環境変数は無い（BM_JOB・BATCH_MODE は runner が付ける）
		Map<String, String> env = new HashMap<>();

		String taskArn = runner.runBatch(BATCH_CODE, env);

		StatResponseResource res = new StatResponseResource();
		res.setReturnCd("ACCEPTED");
		res.setTaskArn(taskArn);

		return ResponseEntity.ok(res);
	}
}
