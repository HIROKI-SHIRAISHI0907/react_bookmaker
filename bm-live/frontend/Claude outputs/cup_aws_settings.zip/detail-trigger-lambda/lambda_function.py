# -*- coding: utf-8 -*-
"""
B016 試合詳細スクレイピング起動 Lambda

aws-s3-detail-data-csv に b016_game_detail_path.json が置かれたら（B012 が毎日 0:10 頃に作る）、
ECS（Fargate）のタスク bm-detail-data-batch を起動する。

呼ばれ方は 2 通り
  1) S3 のイベント通知（event に "Records" がある）: 置かれたファイルを見る
  2) それ以外（EventBridge Scheduler の {"BM_JOB": "B016"}・コンソールのテスト・手動実行など）:
     BUCKET の INPUT_KEY（b016_game_detail_path.json）があるかを見に行く。無ければ起動しない（NOT_FOUND）
     event に {"bucket": "...", "key": "..."} があればそちらを見る

起動しない場合
  - 置かれたのが b016_game_detail_path.json 以外
  - JSON の中に詳細ページの URL が 1 件も無い（B012 は対象 0 件でも {} で上書きするため）
  - 同じタスク（bm-detail-data-batch）が既に動いている（同じ試合を 2 つのタスクで取らないため。SKIP_IF_RUNNING=0 で無効）

環境変数（カッコ内は既定値）
  CLUSTER            (bm-detail-data-cluster)
  TASK_DEFINITION    (bm-detail-data-batch)          ファミリー名。リビジョン付きでも可（bm-detail-data-batch:3）
  CONTAINER_NAME     (bm-detail-data-scraper)
  SUBNETS            カンマ区切り（必須）
  SECURITY_GROUPS    カンマ区切り（必須）
  ASSIGN_PUBLIC_IP   (ENABLED)
  INPUT_KEY          (b016_game_detail_path.json)
  INPUT_KEYS         (INPUT_KEY,b016_game_detail_path_cup.json)  起動する入力 JSON（カンマ区切り）。
                     b016_game_detail_path_cup.json = 大会（ACL など）の出場選手（Lambda cup-schedule-runner が置く。2026-11 追加）
                     スクレイパーには置かれたファイル名を INPUT_JSON_KEY で渡す（そのファイルだけを読んで消す）
  BUCKET             (aws-s3-detail-data-csv)        S3 イベント以外で呼ばれたときに見るバケット
  SKIP_IF_RUNNING    (1)
  SKIP_IF_EMPTY      (1)
  BATCH_CODE         (B016)                          タスクに BM_JOB として渡す・タグに付ける
"""

import json
import os
import urllib.parse

import boto3

CLUSTER = os.getenv("CLUSTER", "bm-detail-data-cluster")
TASK_DEFINITION = os.getenv("TASK_DEFINITION", "bm-detail-data-batch")
CONTAINER_NAME = os.getenv("CONTAINER_NAME", "bm-detail-data-scraper")
SUBNETS = [s.strip() for s in os.getenv("SUBNETS", "").split(",") if s.strip()]
SECURITY_GROUPS = [s.strip() for s in os.getenv("SECURITY_GROUPS", "").split(",") if s.strip()]
ASSIGN_PUBLIC_IP = os.getenv("ASSIGN_PUBLIC_IP", "ENABLED")
INPUT_KEY = os.getenv("INPUT_KEY", "b016_game_detail_path.json")
INPUT_KEYS = [k.strip() for k in os.getenv("INPUT_KEYS", f"{INPUT_KEY},b016_game_detail_path_cup.json").split(",") if k.strip()]
BUCKET = os.getenv("BUCKET", "aws-s3-detail-data-csv")
SKIP_IF_RUNNING = os.getenv("SKIP_IF_RUNNING", "1") == "1"
SKIP_IF_EMPTY = os.getenv("SKIP_IF_EMPTY", "1") == "1"
BATCH_CODE = os.getenv("BATCH_CODE", "B016")

s3 = boto3.client("s3")
ecs = boto3.client("ecs")

URL_KEYS = ("url", "link", "path", "href", "試合リンク文字列", "detail_url", "detailUrl")


def log(msg, **kw):
    print(json.dumps({"msg": msg, **kw}, ensure_ascii=False, default=str), flush=True)


def count_urls(obj) -> int:
    """スクレイパー（parse_input_json）と同じ形を数える: 文字列 / 配列 / {url: ...} / {日付: [...]} / {urls: [...]}"""
    if isinstance(obj, str):
        return 1 if obj.strip() else 0
    if isinstance(obj, list):
        return sum(count_urls(x) for x in obj)
    if isinstance(obj, dict):
        if any(isinstance(obj.get(k), str) and obj.get(k).strip() for k in URL_KEYS):
            return 1
        return sum(count_urls(v) for v in obj.values())
    return 0


def family_of(task_definition: str) -> str:
    """ "bm-detail-data-batch:3" / ARN → "bm-detail-data-batch" """
    name = task_definition.split("/")[-1]
    return name.split(":")[0]


def running_tasks() -> list:
    """動いている（起動中を含む）同じファミリーのタスク。起動中（PROVISIONING / PENDING）も desiredStatus は RUNNING"""
    res = ecs.list_tasks(cluster=CLUSTER, family=family_of(TASK_DEFINITION), desiredStatus="RUNNING", maxResults=10)
    return res.get("taskArns", [])


def run_task(trigger_key: str, url_count: int) -> str:
    if not SUBNETS or not SECURITY_GROUPS:
        raise RuntimeError("SUBNETS / SECURITY_GROUPS が設定されていません")
    res = ecs.run_task(
        cluster=CLUSTER,
        taskDefinition=TASK_DEFINITION,
        launchType="FARGATE",
        platformVersion="LATEST",
        count=1,
        networkConfiguration={"awsvpcConfiguration": {
            "subnets": SUBNETS, "securityGroups": SECURITY_GROUPS, "assignPublicIp": ASSIGN_PUBLIC_IP}},
        overrides={"containerOverrides": [{
            "name": CONTAINER_NAME,
            "environment": [{"name": "BM_JOB", "value": BATCH_CODE},
                            {"name": "INPUT_JSON_KEY", "value": trigger_key}],
        }]},
        tags=[{"key": "batchCode", "value": BATCH_CODE}, {"key": "trigger", "value": "lambda-s3"}],
        startedBy=f"lambda-{BATCH_CODE}"[:36],
    )
    failures = res.get("failures") or []
    tasks = res.get("tasks") or []
    if failures or not tasks:
        raise RuntimeError(f"RunTask に失敗しました: {failures}")
    return tasks[0]["taskArn"]


def targets_of(event) -> list:
    """event から (bucket, key, S3イベントか) の一覧を作る"""
    records = (event or {}).get("Records") or []
    s3_records = [r for r in records if isinstance(r, dict) and "s3" in r]
    if s3_records:
        return [(r["s3"]["bucket"]["name"], urllib.parse.unquote_plus(r["s3"]["object"]["key"]), True)
                for r in s3_records]
    # S3 イベント以外（スケジューラ・テスト・手動）: 入力 JSON があるかを見に行く
    bucket = str((event or {}).get("bucket") or BUCKET).strip()
    key = str((event or {}).get("key") or "").strip()
    if key:
        return [(bucket, key, False)]
    # key の指定が無ければ、入力 JSON をすべて見る（1 つ起動したら、残りは「動いている」で飛ばされ、次の回に起動される）
    return [(bucket, k, False) for k in INPUT_KEYS]


def object_exists(bucket: str, key: str) -> bool:
    try:
        s3.head_object(Bucket=bucket, Key=key)
        return True
    except Exception as e:
        code = getattr(e, "response", {}).get("Error", {}).get("Code", "")
        if code in ("404", "NoSuchKey", "NotFound"):
            return False
        if code in ("403", "AccessDenied", "Forbidden"):
            # s3:ListBucket が無いと、無いファイルも 403 になる
            log("head_object が 403 でした（ファイルが無い、または s3:ListBucket の権限なし）", bucket=bucket, key=key)
            return False
        raise


def lambda_handler(event, context):
    log("event", event=event)
    results = []
    for bucket, key, from_s3_event in targets_of(event):
        if not from_s3_event and not object_exists(bucket, key):
            log("入力 JSON が無いので起動しません", bucket=bucket, key=key)
            results.append({"key": key, "status": "NOT_FOUND"})
            continue
        if key not in INPUT_KEYS:
            log("対象外のファイルなので何もしません", bucket=bucket, key=key)
            results.append({"key": key, "status": "IGNORED"})
            continue

        # 中身を確認（URL が 0 件なら起動しない）
        url_count = -1
        try:
            body = s3.get_object(Bucket=bucket, Key=key)["Body"].read().decode("utf-8-sig")
            url_count = count_urls(json.loads(body)) if body.strip() else 0
        except Exception as e:
            # 読めない場合は起動してスクレイパー側で判定させる（スクレイパーもエラーをログに出す）
            log("JSON を読めませんでした（起動は続けます）", bucket=bucket, key=key, error=str(e))
        if SKIP_IF_EMPTY and url_count == 0:
            log("詳細ページの URL が 0 件なので起動しません", bucket=bucket, key=key)
            results.append({"key": key, "status": "SKIPPED_EMPTY"})
            continue

        # 二重起動の防止
        if SKIP_IF_RUNNING:
            running = running_tasks()
            if running:
                log("同じタスクが動いているので起動しません（取得済みは次回飛ばされるので、残りは次の JSON で取られます）",
                    running=running)
                results.append({"key": key, "status": "SKIPPED_RUNNING", "running": running})
                continue

        task_arn = run_task(key, url_count)
        log("ECS タスクを起動しました", taskArn=task_arn, cluster=CLUSTER, taskDefinition=TASK_DEFINITION,
            urlCount=url_count)
        results.append({"key": key, "status": "STARTED", "taskArn": task_arn, "urlCount": url_count})

    return {"results": results}
