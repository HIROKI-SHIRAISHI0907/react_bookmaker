このフォルダは web では使わない（バッチサービスを作るときの参考）。

- CsvDataUploadService_db_reflect_reference.java.txt
    前回までの「DB チェック・反映」まで web で行っていた版。キーの検索・重複・反映（1 トランザクション）の処理を
    バッチサービスに移すときの元にする。
- CsvDataUploadRepository.java（webMaster DB: シーズン / チーム / 試合予定）
- RealtimeDataUploadRepository.java（bm DB: static_data の非表示・再表示）
    バッチサービス側のリポジトリにする。
