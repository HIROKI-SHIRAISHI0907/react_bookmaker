package dev.web.controller;

import java.io.IOException;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import dev.web.api.bm_a031.CsvDataUploadService;
import dev.web.api.bm_a031.CsvUploadResponse;
import dev.web.api.bm_a031.CsvUploadStatus;
import dev.web.api.bm_a031.UnauthorizedUploadException;
import dev.web.util.CsvUtil;
import lombok.RequiredArgsConstructor;

/**
 * CSVデータのアップロード
 *
 * <h3>アップロード</h3>
 * <p>POST /v1/api/admin/csv/upload/{season|team|future|realtime}（multipart/form-data、項目名 file）</p>
 * <ul>
 *   <li>zip だけ受け付ける。zip の名前は season_ / team_ / future_ / realtime_ で始め、中の CSV は zip と同じ名前にする。</li>
 *   <li>ここではバリデーション（ファイル名・形・必須項目など。DB は見ない）だけ行い、DB への反映はバッチサービスで行う。</li>
 *   <li>200: 判定前（受け付けた。S3 の uploaded/ に置いた）</li>
 *   <li>400: 異常終了（バリデーションエラー。S3 の error/ に {名前}_error.zip を置いた）</li>
 *   <li>500: 異常終了（S3 に置けなかった）</li>
 *   <li>401: 未ログイン（Authorization: Bearer の JWT が無い・不正）。受け付けず、状況管理にも記録しない</li>
 * </ul>
 *
 * <h3>フォーマットのダウンロード</h3>
 * <p>GET /v1/api/admin/csv/upload/{season|team|future|realtime}/format</p>
 * <ul>
 *   <li>ヘッダー行だけの CSV を zip にして返す（例: season_20261018203000.zip の中に season_20261018203000.csv）。</li>
 *   <li>CSV に行を追記して、同じ名前のまま zip にし直せばアップロードできる。</li>
 * </ul>
 *
 * @author shiraishitoshio
 */
@RestController
@RequestMapping("/api/admin/csv/upload")
@RequiredArgsConstructor
public class AdminCsvDataUploadController {

	private final CsvDataUploadService csvDataUploadService;

	/** シーズンデータ（country_league_season_master） */
	@PostMapping(value = "/season", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<CsvUploadResponse> uploadSeason(@RequestParam("file") MultipartFile file) {
		return toResponse(csvDataUploadService.uploadSeason(file));
	}

	/** チームデータ（country_league_master） */
	@PostMapping(value = "/team", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<CsvUploadResponse> uploadTeam(@RequestParam("file") MultipartFile file) {
		return toResponse(csvDataUploadService.uploadTeam(file));
	}

	/** 試合予定データ（future_master） */
	@PostMapping(value = "/future", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<CsvUploadResponse> uploadFuture(@RequestParam("file") MultipartFile file) {
		return toResponse(csvDataUploadService.uploadFuture(file));
	}

	/** リアルタイムデータ（static_data。非表示・再表示のみ） */
	@PostMapping(value = "/realtime", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<CsvUploadResponse> uploadRealtime(@RequestParam("file") MultipartFile file) {
		return toResponse(csvDataUploadService.uploadRealtime(file));
	}

	/**
	 * フォーマット（ヘッダー行だけの CSV を zip にしたもの）のダウンロード
	 * @param masterName season / team / future / realtime
	 */
	@GetMapping("/{masterName}/format")
	public ResponseEntity<byte[]> downloadFormat(@PathVariable("masterName") String masterName) throws IOException {
		CsvUtil.CsvFile zip = csvDataUploadService.downloadFormat(masterName);
		if (zip == null) {
			return ResponseEntity.notFound().build();
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.parseMediaType("application/zip"));
		headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + zip.getFileName() + "\"");
		// 画面（fetch）からファイル名を読めるようにする
		headers.set(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, HttpHeaders.CONTENT_DISPOSITION);
		return ResponseEntity.ok().headers(headers).body(zip.getBytes());
	}

	/** 未ログイン → 401 { message } */
	@ExceptionHandler(UnauthorizedUploadException.class)
	public ResponseEntity<Map<String, String>> handleUnauthorized(UnauthorizedUploadException e) {
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("message", e.getMessage()));
	}

	/**
	 * 判定前（受け付けた）→ 200 / 異常終了（バリデーション）→ 400 / 異常終了（保管失敗）→ 500
	 */
	private static ResponseEntity<CsvUploadResponse> toResponse(CsvUploadResponse res) {
		if (CsvUploadStatus.PENDING.equals(res.getStatus())) {
			return ResponseEntity.ok(res);
		}
		if (CsvUploadStatus.PHASE_STORE.equals(res.getErrorPhase())) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(res);
		}
		return ResponseEntity.badRequest().body(res);
	}
}
