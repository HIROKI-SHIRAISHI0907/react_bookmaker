-- ============================================================
-- soccer_bm: file_upload_status_manage（ファイルアップロード状況管理）を作る
--   CSV アップロード画面（シーズン / チーム / 試合予定 / リアルタイム）からのアップロード 1 回ごとに 1 行。
--
--   流れ:
--     web    : 受付 → status = PENDING（判定前）
--              バリデーション OK → zip を S3 の uploaded/ に置く（PENDING のまま。s3_key に場所）
--              バリデーション NG → {名前}_error.zip を S3 の error/ に置く → status = ERROR（異常終了）, error_phase = VALIDATION
--              S3 に置けない     → status = ERROR, error_phase = STORE
--     バッチ : PENDING を取り出す → PROCESSING（判定中）→ DB チェック・反映
--              OK → success/ に移す → SUCCESS（正常終了）
--              NG → {名前}_error.zip を error/ に置く → ERROR, error_phase = DB
--
--   login_user はログイン中のユーザー（JWT の sub＝メールアドレス）。未ログインのアップロードは受け付けない。
--   register_id / update_id にも同じログインユーザーを入れる（バッチが更新するときはバッチの ID）。
--
--   既にテーブルがある場合は何もしない（前の定義で作った場合は file_upload_status_manage_alter.sql を流す）。
-- ============================================================
BEGIN;

CREATE TABLE IF NOT EXISTS file_upload_status_manage (
  id              BIGSERIAL     NOT NULL,
  master_name     VARCHAR(20)   NOT NULL,
  file_name       VARCHAR(255)  NOT NULL,
  csv_file_name   VARCHAR(255),
  file_size       BIGINT        NOT NULL DEFAULT 0,
  status          VARCHAR(20)   NOT NULL,
  error_phase     VARCHAR(20),
  message         TEXT,
  total_count     INTEGER       NOT NULL DEFAULT 0,
  insert_count    INTEGER       NOT NULL DEFAULT 0,
  update_count    INTEGER       NOT NULL DEFAULT 0,
  delete_count    INTEGER       NOT NULL DEFAULT 0,
  hide_count      INTEGER       NOT NULL DEFAULT 0,
  show_count      INTEGER       NOT NULL DEFAULT 0,
  error_count     INTEGER       NOT NULL DEFAULT 0,
  error_detail    JSONB,
  login_user      VARCHAR(255)  NOT NULL,
  started_at      TIMESTAMP(0) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  finished_at     TIMESTAMP(0) WITH TIME ZONE,
  s3_bucket       VARCHAR(255),
  s3_key          VARCHAR(1024),
  register_id     VARCHAR(100)  NOT NULL,
  register_time   TIMESTAMP(0) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  update_id       VARCHAR(100)  NOT NULL,
  update_time     TIMESTAMP(0) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT pk_file_upload_status_manage PRIMARY KEY (id),
  CONSTRAINT ck_file_upload_status_manage_master CHECK (master_name IN ('season', 'team', 'future', 'realtime')),
  CONSTRAINT ck_file_upload_status_manage_status CHECK (status IN ('PENDING', 'PROCESSING', 'SUCCESS', 'ERROR')),
  CONSTRAINT ck_file_upload_status_manage_phase  CHECK (error_phase IS NULL OR error_phase IN ('VALIDATION', 'STORE', 'DB'))
);

CREATE INDEX IF NOT EXISTS idx_file_upload_status_manage_started
    ON file_upload_status_manage (started_at DESC);
CREATE INDEX IF NOT EXISTS idx_file_upload_status_manage_master_started
    ON file_upload_status_manage (master_name, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_file_upload_status_manage_login_user
    ON file_upload_status_manage (login_user, started_at DESC);
-- バッチサービスが判定前を古い順に取り出すため
CREATE INDEX IF NOT EXISTS idx_file_upload_status_manage_status_started
    ON file_upload_status_manage (status, started_at);


COMMENT ON TABLE  file_upload_status_manage IS 'ファイルアップロード状況管理（CSVアップロード 1 回ごとの受付と結果）';
COMMENT ON COLUMN file_upload_status_manage.id            IS 'ID（S3 のキーのフォルダにも使う）';
COMMENT ON COLUMN file_upload_status_manage.master_name   IS '種類 season:シーズン team:チーム future:試合予定 realtime:リアルタイム';
COMMENT ON COLUMN file_upload_status_manage.file_name     IS 'アップロードした zip の名前';
COMMENT ON COLUMN file_upload_status_manage.csv_file_name IS 'zip の中の CSV の名前（zip と同じ名前）';
COMMENT ON COLUMN file_upload_status_manage.file_size     IS 'zip のサイズ（バイト）';
COMMENT ON COLUMN file_upload_status_manage.status        IS '状態 PENDING:判定前 PROCESSING:判定中 SUCCESS:正常終了 ERROR:異常終了';
COMMENT ON COLUMN file_upload_status_manage.error_phase   IS 'エラーの段階 VALIDATION:バリデーション STORE:S3保管 DB:DBチェック・反映（異常終了のときだけ）';
COMMENT ON COLUMN file_upload_status_manage.message       IS '結果メッセージ';
COMMENT ON COLUMN file_upload_status_manage.total_count   IS 'CSV の行数（見出し・空行を除く）';
COMMENT ON COLUMN file_upload_status_manage.insert_count  IS '登録件数（バッチ）';
COMMENT ON COLUMN file_upload_status_manage.update_count  IS '更新件数（バッチ）';
COMMENT ON COLUMN file_upload_status_manage.delete_count  IS '削除件数（バッチ）';
COMMENT ON COLUMN file_upload_status_manage.hide_count    IS '非表示件数（バッチ）';
COMMENT ON COLUMN file_upload_status_manage.show_count    IS '再表示件数（バッチ）';
COMMENT ON COLUMN file_upload_status_manage.error_count   IS 'エラー行数';
COMMENT ON COLUMN file_upload_status_manage.error_detail  IS 'エラー行（[{rowNo, operation, key, message}]。最大 1000 行。rowNo=0 はファイル全体）';
COMMENT ON COLUMN file_upload_status_manage.login_user    IS 'アップロードしたログインユーザー（メールアドレス。JWT の sub）';
COMMENT ON COLUMN file_upload_status_manage.started_at    IS '受付日時';
COMMENT ON COLUMN file_upload_status_manage.finished_at   IS '終了日時（正常終了・異常終了になった日時）';
COMMENT ON COLUMN file_upload_status_manage.s3_bucket     IS '置いた S3 バケット（aws-s3-upload-check-csv）';
COMMENT ON COLUMN file_upload_status_manage.s3_key        IS '置いた S3 キー（uploaded/ ・ success/ ・ error/ の {種類}/{yyyyMMdd}/{id}/ファイル名）';

-- 確認
SELECT column_name, data_type FROM information_schema.columns
 WHERE table_schema = current_schema() AND table_name = 'file_upload_status_manage'
 ORDER BY ordinal_position;

COMMIT;
